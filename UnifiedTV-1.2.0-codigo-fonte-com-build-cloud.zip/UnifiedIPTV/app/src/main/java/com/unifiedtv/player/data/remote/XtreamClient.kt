package com.unifiedtv.player.data.remote

import android.util.JsonReader
import android.util.JsonToken
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStreamReader

/** Cliente da API Xtream Codes (player_api.php). */
class XtreamClient(
    private val http: OkHttpClient,
    rawBaseUrl: String,
    private val username: String,
    private val password: String
) {
    val baseUrl: String = rawBaseUrl.trim().trimEnd('/').let {
        val noApi = it.substringBefore("/player_api.php").substringBefore("/get.php")
        if (noApi.startsWith("http")) noApi else "http://$noApi"
    }

    private fun apiUrl(action: String?, extra: Map<String, String> = emptyMap()): String {
        val b = "$baseUrl/player_api.php".toHttpUrl().newBuilder()
            .addQueryParameter("username", username)
            .addQueryParameter("password", password)
        if (action != null) b.addQueryParameter("action", action)
        extra.forEach { (k, v) -> b.addQueryParameter(k, v) }
        return b.build().toString()
    }

    /** Lê um array JSON em streaming entregando cada objeto como mapa de campos primitivos. */
    private fun streamArray(action: String, onItem: (Map<String, String?>) -> Unit) {
        http.newCall(Request.Builder().url(apiUrl(action)).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} em $action")
            val body = resp.body ?: throw IOException("Resposta vazia em $action")
            JsonReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { r ->
                r.isLenient = true
                if (r.peek() != JsonToken.BEGIN_ARRAY) { r.skipValue(); return }
                r.beginArray()
                while (r.hasNext()) {
                    if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    val map = HashMap<String, String?>(24)
                    r.beginObject()
                    while (r.hasNext()) {
                        val name = r.nextName()
                        when (r.peek()) {
                            JsonToken.STRING, JsonToken.NUMBER -> map[name] = r.nextString()
                            JsonToken.BOOLEAN -> map[name] = r.nextBoolean().toString()
                            JsonToken.NULL -> { r.nextNull(); map[name] = null }
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    onItem(map)
                }
                r.endArray()
            }
        }
    }

    fun authenticate() {
        http.newCall(Request.Builder().url(apiUrl(null)).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Falha de autenticação Xtream (HTTP ${resp.code})")
            val json = JSONObject(resp.body?.string().orEmpty())
            val auth = json.optJSONObject("user_info")?.opt("auth")?.toString()
            if (auth != "1") throw IOException("Usuário/senha Xtream inválidos")
        }
    }

    fun categories(action: String): Map<String, String> {
        val out = HashMap<String, String>()
        streamArray(action) { m ->
            val id = m["category_id"] ?: return@streamArray
            out[id] = m["category_name"].orEmpty()
        }
        return out
    }

    fun liveStreams(onItem: (Map<String, String?>) -> Unit) = streamArray("get_live_streams", onItem)
    fun vodStreams(onItem: (Map<String, String?>) -> Unit) = streamArray("get_vod_streams", onItem)
    fun series(onItem: (Map<String, String?>) -> Unit) = streamArray("get_series", onItem)

    fun liveUrl(streamId: String, ext: String = "m3u8") = "$baseUrl/live/$username/$password/$streamId.$ext"
    fun movieUrl(streamId: String, ext: String?) = "$baseUrl/movie/$username/$password/$streamId.${ext ?: "mp4"}"
    fun episodeUrl(id: String, ext: String?) = "$baseUrl/series/$username/$password/$id.${ext ?: "mp4"}"

    data class XEpisode(val season: Int, val episode: Int, val title: String, val url: String, val logo: String?)

    fun seriesEpisodes(seriesId: String): List<XEpisode> {
        val req = Request.Builder().url(apiUrl("get_series_info", mapOf("series_id" to seriesId))).build()
        val text = http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} em get_series_info")
            resp.body?.string().orEmpty()
        }
        val root = JSONObject(text)
        val out = ArrayList<XEpisode>()
        fun addEpisode(seasonKey: String?, o: JSONObject) {
            val id = o.opt("id")?.toString() ?: return
            val season = o.optString("season", seasonKey ?: "1").toIntOrNull() ?: seasonKey?.toIntOrNull() ?: 1
            val ep = o.optString("episode_num", "0").toIntOrNull() ?: 0
            val info = o.optJSONObject("info")
            out += XEpisode(
                season = season, episode = ep,
                title = o.optString("title", "Episódio $ep"),
                url = episodeUrl(id, o.optString("container_extension", "mp4").ifBlank { "mp4" }),
                logo = info?.optString("movie_image")?.takeIf { it.isNotBlank() }
            )
        }
        when (val eps = root.opt("episodes")) {
            is JSONObject -> eps.keys().forEach { k ->
                val arr = eps.optJSONArray(k) ?: return@forEach
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { addEpisode(k, it) }
            }
            is JSONArray -> for (i in 0 until eps.length()) {
                when (val s = eps.opt(i)) {
                    is JSONArray -> for (j in 0 until s.length()) s.optJSONObject(j)?.let { addEpisode(null, it) }
                    is JSONObject -> addEpisode(null, s)
                }
            }
        }
        return out
    }
}
