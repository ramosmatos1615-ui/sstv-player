package com.unifiedtv.player.data.sports

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/** Dados públicos de placares ESPN. A agenda é independente das listas IPTV. */
data class SportsGame(
    val id: String,
    val league: String,
    val homeName: String,
    val awayName: String,
    val homeLogo: String?,
    val awayLogo: String?,
    val homeScore: String,
    val awayScore: String,
    val status: String,
    val clock: String,
    val isLive: Boolean,
    val networks: List<String>,
    val startTime: String
)

class SportsRepository(private val http: OkHttpClient) {
    private data class League(val path: String, val name: String)

    private val leagues = listOf(
        League("soccer/bra.1", "Brasileirão"),
        League("soccer/bra.copa_do_brasil", "Copa do Brasil"),
        League("soccer/conmebol.libertadores", "Libertadores"),
        League("soccer/uefa.champions", "Champions League"),
        League("soccer/eng.1", "Premier League"),
        League("soccer/esp.1", "LaLiga"),
        League("basketball/nba", "NBA"),
        League("football/nfl", "NFL"),
        League("baseball/mlb", "MLB"),
        League("hockey/nhl", "NHL")
    )

    suspend fun today(): List<SportsGame> = withContext(Dispatchers.IO) {
        val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        coroutineScope {
            leagues.map { league -> async { runCatching { fetch(league, date) }.getOrDefault(emptyList()) } }
                .awaitAll().flatten().distinctBy { it.id }
                .sortedWith(compareBy<SportsGame>({ !it.isLive }, { it.startTime }))
        }
    }

    private fun fetch(league: League, date: String): List<SportsGame> {
        val url = "https://site.api.espn.com/apis/site/v2/sports/${league.path}/scoreboard?dates=$date"
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        http.newBuilder().callTimeout(15, TimeUnit.SECONDS).build().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val root = JSONObject(response.body?.string().orEmpty())
            val events = root.optJSONArray("events") ?: return emptyList()
            return (0 until events.length()).mapNotNull { index ->
                runCatching { parseEvent(events.getJSONObject(index), league.name) }.getOrNull()
            }
        }
    }

    private fun parseEvent(event: JSONObject, league: String): SportsGame? {
        val competition = event.optJSONArray("competitions")?.optJSONObject(0) ?: return null
        val competitors = competition.optJSONArray("competitors") ?: return null
        var home: JSONObject? = null
        var away: JSONObject? = null
        for (i in 0 until competitors.length()) {
            val c = competitors.optJSONObject(i) ?: continue
            if (c.optString("homeAway") == "home") home = c else if (c.optString("homeAway") == "away") away = c
        }
        home ?: return null
        away ?: return null
        val statusObj = event.optJSONObject("status")?.optJSONObject("type")
        val state = statusObj?.optString("state").orEmpty()
        val live = state == "in"
        val status = when (state) {
            "in" -> "AO VIVO"
            "post" -> "Encerrado"
            else -> statusObj?.optString("shortDetail")?.takeIf { it.isNotBlank() }
                ?: statusObj?.optString("detail")?.takeIf { it.isNotBlank() } ?: "Agendado"
        }
        val statusRoot = event.optJSONObject("status")
        val clock = if (live) buildString {
            val period = statusRoot?.optInt("period", 0) ?: 0
            val display = statusRoot?.optString("displayClock").orEmpty()
            if (display.isNotBlank() && display != "0:00") append(display)
            if (period > 0) { if (isNotEmpty()) append(" • "); append("Período ").append(period) }
        }.ifBlank { "Em andamento" } else status

        val networks = linkedSetOf<String>()
        val broadcasts = competition.optJSONArray("broadcasts")
        if (broadcasts != null) for (i in 0 until broadcasts.length()) {
            val b = broadcasts.optJSONObject(i) ?: continue
            val nameArray = b.optJSONArray("names")
            if (nameArray != null) {
                for (j in 0 until nameArray.length()) nameArray.optString(j).takeIf { it.isNotBlank() && it != "null" }?.let(networks::add)
            } else {
                b.optString("names").takeIf { it.isNotBlank() && it != "null" }?.let { names ->
                    names.split(",").map(String::trim).filter(String::isNotBlank).forEach(networks::add)
                }
            }
            b.optString("name").takeIf { it.isNotBlank() && it != "null" }?.let(networks::add)
        }
        val geo = competition.optJSONArray("geoBroadcasts")
        if (geo != null) for (i in 0 until geo.length()) {
            val media = geo.optJSONObject(i)?.optJSONObject("media")
            media?.optString("shortName")?.takeIf { it.isNotBlank() && it != "null" }?.let(networks::add)
        }
        val homeTeam = home.optJSONObject("team") ?: JSONObject()
        val awayTeam = away.optJSONObject("team") ?: JSONObject()
        val date = event.optString("date")
        val start = runCatching {
            val patterns = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm'Z'")
            val parsed = patterns.firstNotNullOfOrNull { pattern ->
                runCatching { SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(date) }.getOrNull()
            }
            if (parsed == null) "" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(parsed)
        }.getOrDefault("")
        return SportsGame(
            id = event.optString("id"), league = league,
            homeName = homeTeam.optString("displayName", homeTeam.optString("name", "Mandante")),
            awayName = awayTeam.optString("displayName", awayTeam.optString("name", "Visitante")),
            homeLogo = homeTeam.optString("logo").takeIf { it.startsWith("http") },
            awayLogo = awayTeam.optString("logo").takeIf { it.startsWith("http") },
            homeScore = home.optString("score", "-"), awayScore = away.optString("score", "-"),
            status = status, clock = clock, isLive = live, networks = networks.toList(), startTime = start
        )
    }
}
