package com.unifiedtv.player.data.parser

import java.io.BufferedReader

data class M3uEntry(
    val title: String,
    val url: String,
    val attrs: Map<String, String>,
    val group: String?,
    val userAgent: String?,
    val referer: String?,
    /** Duração do #EXTINF (-1/0 = ao vivo; valores positivos indicam VOD). */
    val duration: Double? = null
)

/**
 * Parser M3U/M3U8 em streaming (linha a linha) - suporta listas com centenas de
 * milhares de entradas sem carregar o arquivo inteiro na memória.
 * Suporta #EXTINF com atributos, #EXTGRP, #EXTVLCOPT (user-agent/referrer) e
 * cabeçalhos via pipe: http://url|User-Agent=xxx&Referer=yyy
 */
object M3uParser {
    private val attrRegex = Regex("""([\w\-]+)="([^"]*)"""")

    fun parse(reader: BufferedReader, onEntry: (M3uEntry) -> Unit) = entries(reader).forEach(onEntry)

    /** Sequência preguiçosa: lê uma linha por vez conforme as entradas são consumidas. */
    fun entries(reader: BufferedReader): Sequence<M3uEntry> = sequence {
        var pendingInfo: String? = null
        var pendingGroup: String? = null
        var ua: String? = null
        var ref: String? = null

        while (true) {
            val rawLine = reader.readLine() ?: break
            val line = rawLine.trim().removePrefix("\uFEFF")
            when {
                line.isEmpty() -> Unit
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingInfo = line; pendingGroup = null; ua = null; ref = null
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> pendingGroup = line.substringAfter(':').trim()
                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val opt = line.substringAfter(':')
                    val k = opt.substringBefore('=').trim().lowercase()
                    val v = opt.substringAfter('=', "").trim()
                    if (k == "http-user-agent") ua = v
                    if (k == "http-referrer" || k == "http-referer") ref = v
                }
                line.startsWith("#") -> Unit
                else -> {
                    val info = pendingInfo
                    var url = line
                    var lineUa = ua
                    var lineRef = ref
                    if (url.contains('|')) {
                        val opts = url.substringAfter('|')
                        url = url.substringBefore('|')
                        opts.split('&').forEach { kv ->
                            val k = kv.substringBefore('=').trim().lowercase()
                            val v = kv.substringAfter('=', "").trim()
                            if (k == "user-agent") lineUa = v
                            if (k == "referer" || k == "referrer") lineRef = v
                        }
                    }
                    if (url.startsWith("http", true) || url.startsWith("rtmp", true) ||
                        url.startsWith("rtsp", true) || url.startsWith("udp", true)) {
                        val attrs = if (info != null) parseAttrs(info) else emptyMap()
                        val title = (if (info != null) parseTitle(info) else null)
                            ?.takeIf { it.isNotBlank() }
                            ?: attrs["tvg-name"]?.takeIf { it.isNotBlank() }
                            ?: url.substringAfterLast('/')
                        yield(
                            M3uEntry(
                                title = title.trim(),
                                url = url,
                                attrs = attrs,
                                group = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: pendingGroup,
                                userAgent = lineUa ?: attrs["user-agent"],
                                referer = lineRef ?: attrs["referer"] ?: attrs["referrer"],
                                duration = info?.let { parseDuration(it) }
                            )
                        )
                    }
                    pendingInfo = null; ua = null; ref = null
                }
            }
        }
    }

    internal fun parseDuration(info: String): Double? =
        info.substringAfter(':', "").trimStart().takeWhile { it == '-' || it == '.' || it.isDigit() }.toDoubleOrNull()

    internal fun parseAttrs(info: String): Map<String, String> =
        attrRegex.findAll(info).associate { it.groupValues[1].lowercase() to it.groupValues[2] }

    /** O título fica após a primeira vírgula que não está dentro de aspas. */
    internal fun parseTitle(info: String): String? {
        var inQuotes = false
        for (i in info.indices) {
            val c = info[i]
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) return info.substring(i + 1).trim()
        }
        return null
    }
}
