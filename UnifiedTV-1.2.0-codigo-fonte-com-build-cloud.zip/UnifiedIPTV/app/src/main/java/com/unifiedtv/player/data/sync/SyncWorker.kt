package com.unifiedtv.player.data.sync

import android.content.Context
import androidx.work.*
import com.unifiedtv.player.UnifiedApp
import java.util.concurrent.TimeUnit

/** Atualiza o cache de todas as listas em segundo plano. */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        (applicationContext as UnifiedApp).container.syncManager.syncAll(force = false)
        return Result.success()
    }

    companion object {
        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(12, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork("playlist-sync", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
