package com.unifiedtv.player.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.cachedIn
import com.unifiedtv.player.data.FAVORITES
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.db.CategoryCount
import com.unifiedtv.player.data.db.ContentType
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(val repo: MediaRepository) : ViewModel() {
    val type = MutableStateFlow(ContentType.LIVE)
    val category = MutableStateFlow<String?>(null)

    val categories: StateFlow<List<CategoryCount>> = type
        .flatMapLatest { repo.categories(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val items = combine(type, category) { t, c -> t to c }
        .flatMapLatest { (t, c) -> repo.items(t, c) }
        .cachedIn(viewModelScope)

    val syncState = repo.sync.state
    val playlists = repo.observePlaylists().stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun selectType(t: ContentType) { type.value = t; category.value = null }
    fun selectCategory(c: String?) { category.value = c }
    fun refreshAll() = viewModelScope.launch { repo.sync.syncAll(force = true) }

    companion object { const val FAV = FAVORITES }
}
