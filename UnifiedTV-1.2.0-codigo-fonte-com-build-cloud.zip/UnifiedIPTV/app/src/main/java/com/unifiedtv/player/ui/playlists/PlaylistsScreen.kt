package com.unifiedtv.player.ui.playlists

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.unifiedtv.player.UnifiedApp
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.db.PlaylistEntity
import com.unifiedtv.player.data.db.SourceType
import com.unifiedtv.player.ui.common.EmptyState
import com.unifiedtv.player.ui.common.repoFactory
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class PlaylistsViewModel(private val repo: MediaRepository) : ViewModel() {
    val playlists = repo.observePlaylists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sync = repo.sync.state

    // Usa o escopo da aplicação: a sincronização continua mesmo saindo da tela
    private fun bg(block: suspend () -> Unit) = (UnifiedAppHolder.app?.appScope ?: viewModelScope).launch { block() }

    fun add(name: String, type: SourceType, url: String, user: String?, pass: String?) =
        bg { repo.addPlaylist(name, type, url, user, pass) }
    fun toggle(p: PlaylistEntity) = viewModelScope.launch { repo.setEnabled(p, !p.enabled) }
    fun delete(p: PlaylistEntity) = viewModelScope.launch { repo.delete(p) }
    fun refresh(p: PlaylistEntity) = bg { repo.refresh(p) }
    fun move(p: PlaylistEntity, up: Boolean) = viewModelScope.launch { repo.move(p, up) }
}

object UnifiedAppHolder { var app: UnifiedApp? = null }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(onBack: () -> Unit) {
    val vm: PlaylistsViewModel = viewModel(factory = repoFactory { PlaylistsViewModel(it) })
    val list by vm.playlists.collectAsStateWithLifecycle()
    val sync by vm.sync.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<PlaylistEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Minhas listas") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAdd = true }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Adicionar") })
        }
    ) { pad ->
        if (list.isEmpty()) {
            Box(Modifier.padding(pad)) { EmptyState("Adicione quantas listas quiser. Todas são carregadas juntas e mescladas em categorias únicas.") }
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp)) {
            item {
                Text("A ordem define a prioridade: quando o mesmo canal existe em várias listas, a primeira é tentada antes e as demais servem de reserva automática.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp))
            }
            items(list, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text(if (p.type == SourceType.XTREAM) "Xtream Codes • ${p.username}" else "M3U",
                                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = p.enabled, onCheckedChange = { vm.toggle(p) })
                        }
                        val progress = sync.progress[p.id]
                        when {
                            progress != null -> {
                                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                                Text("Sincronizando… $progress itens", style = MaterialTheme.typography.bodySmall)
                            }
                            p.lastError != null -> Text("Erro: ${p.lastError}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            p.lastSync > 0 -> Text("${p.itemCount} itens • atualizada ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.lastSync))}",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Row {
                            IconButton(onClick = { vm.move(p, true) }) { Icon(Icons.Default.KeyboardArrowUp, "Subir prioridade") }
                            IconButton(onClick = { vm.move(p, false) }) { Icon(Icons.Default.KeyboardArrowDown, "Descer prioridade") }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { vm.refresh(p) }, enabled = progress == null) { Icon(Icons.Default.Refresh, "Atualizar") }
                            IconButton(onClick = { confirmDelete = p }) { Icon(Icons.Default.Delete, "Remover") }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddPlaylistDialog(onDismiss = { showAdd = false }) { name, type, url, u, pw ->
        vm.add(name, type, url, u, pw); showAdd = false
    }
    confirmDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Remover \"${p.name}\"?") },
            text = { Text("Os canais, filmes e séries desta lista serão removidos do cache.") },
            confirmButton = { TextButton(onClick = { vm.delete(p); confirmDelete = null }) { Text("Remover") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun AddPlaylistDialog(onDismiss: () -> Unit, onAdd: (String, SourceType, String, String?, String?) -> Unit) {
    val context = LocalContext.current
    var type by remember { mutableStateOf(SourceType.M3U) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            url = uri.toString()
            if (name.isBlank()) name = "Arquivo local"
        }
    }
    val valid = name.isNotBlank() && url.isNotBlank() && (type == SourceType.M3U || (user.isNotBlank() && pass.isNotBlank()))

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova lista") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row {
                    FilterChip(selected = type == SourceType.M3U, onClick = { type = SourceType.M3U }, label = { Text("M3U / M3U8") }, modifier = Modifier.padding(end = 8.dp))
                    FilterChip(selected = type == SourceType.XTREAM, onClick = { type = SourceType.XTREAM }, label = { Text("Xtream Codes") })
                }
                OutlinedTextField(name, { name = it }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(url, { url = it },
                    label = { Text(if (type == SourceType.M3U) "URL da lista (.m3u)" else "Servidor (http://host:porta)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
                if (type == SourceType.M3U) {
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Escolher arquivo do aparelho") }
                } else {
                    OutlinedTextField(user, { user = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pass, { pass = it }, label = { Text("Senha") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                onAdd(name.trim(), type, url.trim(), user.takeIf { type == SourceType.XTREAM }, pass.takeIf { type == SourceType.XTREAM })
            }) { Text("Adicionar e carregar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
