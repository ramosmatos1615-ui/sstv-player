package com.unifiedtv.player.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.paging.PagingData
import androidx.paging.cachedIn
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.paging.compose.itemKey
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.db.ContentType
import com.unifiedtv.player.ui.common.EmptyState
import com.unifiedtv.player.ui.common.MediaCard
import com.unifiedtv.player.ui.common.playUnified
import com.unifiedtv.player.ui.common.toggleFavorite
import com.unifiedtv.player.ui.common.repoFactory
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class SearchViewModel(val repo: MediaRepository) : ViewModel() {
    val query = MutableStateFlow("")
    val type = MutableStateFlow<ContentType?>(null)
    val results = combine(query.debounce(300).map { it.trim() }.distinctUntilChanged(), type) { q, t -> q to t }
        .flatMapLatest { (q, t) -> if (q.length < 2) flowOf(PagingData.empty()) else repo.search(q, t) }
        .cachedIn(viewModelScope)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onBack: () -> Unit, onSeries: (String) -> Unit) {
    val vm: SearchViewModel = viewModel(factory = repoFactory { SearchViewModel(it) })
    val q by vm.query.collectAsStateWithLifecycle()
    val type by vm.type.collectAsStateWithLifecycle()
    val results = vm.results.collectAsLazyPagingItems()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Scaffold(topBar = {
        Column {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
                title = {
                    OutlinedTextField(
                        value = q, onValueChange = { vm.query.value = it }, singleLine = true,
                        placeholder = { Text("Buscar em todas as listas…") },
                        modifier = Modifier.fillMaxWidth().padding(end = 8.dp).focusRequester(focus)
                    )
                }
            )
            Row(Modifier.padding(horizontal = 8.dp)) {
                listOf(null to "Tudo", ContentType.LIVE to "Ao vivo", ContentType.MOVIE to "Filmes", ContentType.SERIES to "Séries")
                    .forEach { (t, label) ->
                        FilterChip(selected = type == t, onClick = { vm.type.value = t }, label = { Text(label) }, modifier = Modifier.padding(4.dp))
                    }
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (q.trim().length < 2) EmptyState("Digite ao menos 2 letras. A busca cobre canais, filmes e séries de todas as listas ativas.")
            else if (results.itemCount == 0) EmptyState("Nenhum resultado para \"$q\".")
            else LazyVerticalGrid(GridCells.Adaptive(115.dp), contentPadding = PaddingValues(6.dp)) {
                items(count = results.itemCount, key = results.itemKey { it.contentKey }) { i ->
                    val item = results[i] ?: return@items
                    MediaCard(item, onLongClick = { scope.launch { toggleFavorite(context, vm.repo, item) } }) {
                        if (item.type == ContentType.SERIES) onSeries(item.contentKey)
                        else scope.launch { playUnified(context, vm.repo, item) }
                    }
                }
            }
        }
    }
}
