package com.unifiedtv.player.data.normalize

import com.unifiedtv.player.data.db.ContentType
import com.unifiedtv.player.data.parser.M3uEntry

/**
 * Classifica entradas M3U em Ao vivo / Filme / Série por PONTUAÇÃO de vários sinais:
 *  1. tvg-type / type explícito (decisivo)
 *  2. Caminho da URL (/live/, /movie/, /series/, /vod/, /timeshift/)
 *  3. Extensão (.mp4/.mkv... = VOD; .ts/.m3u8/sem extensão em formato Xtream = ao vivo)
 *  4. Duração positiva no #EXTINF (VOD)
 *  5. Padrões de episódio no título (fortes e fracos) e ano de lançamento
 *  6. Palavras-chave do grupo (canais, filmes, séries, novelas, 24h, rádio…)
 *  7. Perfil estatístico do GRUPO (1ª passada pela lista): entradas ambíguas herdam
 *     o tipo predominante do grupo a que pertencem.
 */
object ContentClassifier {

    data class Result(
        val type: ContentType,
        val episode: MediaTitleParser.EpisodeInfo?,
        val movie: MediaTitleParser.MovieInfo?,
        val margin: Double
    )

    /** Distribuição de tipos de um grupo (0..1). */
    data class GroupPrior(val live: Double, val movie: Double, val series: Double, val n: Int)

    private val IC = RegexOption.IGNORE_CASE
    private val vodExt = Regex("""\.(mp4|mkv|avi|mov|wmv|flv|m4v|webm|mpg|mpeg|divx|xvid|3gp|ogv)$""", IC)
    private val hlsExt = Regex("""\.(m3u8|ts|mpd)$""", IC)
    private val xtreamLive = Regex("""^https?://[^/]+/(?:live/)?[^/]+/[^/]+/\d+(?:\.(?:ts|m3u8))?$""", IC)
    private val h24 = Regex("""(^|\W)(24\s*h(rs?)?|24\s*/\s*7|24x7|24\s*horas)(\W|$)""", IC)

    private val liveGroup = Regex("""\b(canais|canal|channels?|tv|ao vivo|live|ppv|eventos?|radios?|abertos?|""" +
        """noticias|news|esportes?|sports?|futebol|regionais|locais|religiosos?|musica|adultos?|xxx|pluto|samsung tv)\b""", IC)
    private val movieGroup = Regex("""\b(filmes?|movies?|vod|cinema|lancamentos?|estreias?|coletaneas?|colecao|colecoes|""" +
        """collections?|sagas?|trilogias?|franquias?|oscar|longas?)\b""", IC)
    private val seriesGroup = Regex("""\b(series?|temporadas?|seasons?|novelas?|telenovelas?|animes?|doramas?|k ?dramas?|""" +
        """sitcoms?|minisseries?|reality|episodios?|capitulos?)\b""", IC)
    private val streamingBrand = Regex("""\b(netflix|amazon|prime video|hbo|max|disney|apple tv|globoplay|paramount|star plus|crunchyroll)\b""", IC)

    fun classify(e: M3uEntry, prior: GroupPrior? = null): Result {
        val title = MediaTitleParser.prepare(e.title)
        val tvgName = e.attrs["tvg-name"]?.let { MediaTitleParser.prepare(it) }
        val group = TextNormalizer.stripAccents(e.group.orEmpty()).lowercase().replace(Regex("""[|_\-:\[\]()•»/]+"""), " ")
        val url = e.url.substringBefore('?').substringBefore('#')
        val path = url.lowercase()

        var parsedEp = MediaTitleParser.parseEpisode(title, e.group)
            ?: tvgName?.let { MediaTitleParser.parseEpisode(it, e.group) }
        // "/series/…" ou grupo "Temporada 2" com título terminando em número: "Breaking Bad 05"
        val ctxSeason = MediaTitleParser.seasonFromContext(e.group)
        if (parsedEp == null && ("/series/" in path || ctxSeason != null)) {
            Regex("""^(.*?)[\s\-–#]+0*(\d{1,4})\s*$""").find(MediaTitleParser.cleanName(title))?.let { m ->
                parsedEp = MediaTitleParser.EpisodeInfo(m.groupValues[1].trim(), ctxSeason ?: 1, m.groupValues[2].toInt(), null, null, false)
            }
        }
        val episode = parsedEp
        val movie = MediaTitleParser.parseMovie(title).let { m ->
            if (m.year == null && tvgName != null) MediaTitleParser.parseMovie(tvgName).takeIf { it.year != null } ?: m else m
        }

        // 1. tipo explícito
        when ((e.attrs["tvg-type"] ?: e.attrs["type"])?.lowercase()?.trim()) {
            "live", "stream", "channel", "tv" -> return Result(ContentType.LIVE, null, null, 99.0)
            "movie", "movies", "vod", "film" -> return finish(ContentType.MOVIE, episode, movie, e.group, 99.0)
            "series", "serie", "episode", "tvshow" -> return finish(ContentType.SERIES, episode, movie, e.group, 99.0)
        }

        var live = 0.0; var mov = 0.0; var ser = 0.0

        // 2. caminho da URL
        when {
            "/series/" in path -> ser += 10
            "/movie/" in path || "/movies/" in path || "/vod/" in path || "/filmes/" in path -> mov += 10
            "/live/" in path || "/timeshift/" in path || "/streaming/" in path -> live += 10
        }
        // 3. extensão
        when {
            vodExt.containsMatchIn(path) -> { mov += 4; ser += 4 }
            xtreamLive.matches(url) -> live += 5
            hlsExt.containsMatchIn(path) -> live += 3
            !path.substringAfterLast('/').contains('.') -> live += 2
        }
        // 4. duração
        e.duration?.let { if (it > 60) { mov += 3; ser += 3 } else if (it > 0) { mov += 1; ser += 1 } }
        if (e.attrs.containsKey("catchup") || e.attrs.containsKey("catchup-days") || e.attrs.containsKey("timeshift")) live += 4

        // 5. título
        if (episode != null) ser += if (episode.strong) 7.0 else 3.0
        if (movie.year != null && episode == null) mov += if (Regex("""[(\[]\s*${movie.year}\s*[)\]]""").containsMatchIn(title)) 3.0 else 1.5
        if (MediaTitleParser.detectVariant(title)?.let { "DUB" in it || "LEG" in it || "DUAL" in it } == true) { mov += 1; ser += 1 }
        if (h24.containsMatchIn(title) || h24.containsMatchIn(group)) live += 9

        // 6. grupo
        val gLive = liveGroup.containsMatchIn(group)
        val gMovie = movieGroup.containsMatchIn(group)
        val gSeries = seriesGroup.containsMatchIn(group)
        if (gLive) live += 3
        if (gMovie) mov += 3
        if (gSeries) ser += 3
        if (streamingBrand.containsMatchIn(group) && !gLive) { mov += 1; ser += 1 }
        if (group.contains("radio")) live += 5

        // 7. perfil do grupo
        if (prior != null && prior.n >= 3) {
            live += 4 * prior.live; mov += 4 * prior.movie; ser += 4 * prior.series
        }

        // série sem número de episódio não é episódio: vira filme (VOD avulso)
        if (episode == null) { mov = maxOf(mov, ser - 0.5); ser = 0.0 }

        val ranked = listOf(ContentType.LIVE to live, ContentType.MOVIE to mov, ContentType.SERIES to ser)
            .sortedByDescending { it.second }
        val top = ranked[0]
        if (top.second <= 0.0) return Result(ContentType.LIVE, null, null, 0.0)
        return finish(top.first, episode, movie, e.group, top.second - ranked[1].second)
    }

    private fun finish(
        type: ContentType, ep: MediaTitleParser.EpisodeInfo?, movie: MediaTitleParser.MovieInfo,
        group: String?, margin: Double
    ): Result = when (type) {
        ContentType.SERIES -> {
            val e = ep ?: MediaTitleParser.EpisodeInfo("", MediaTitleParser.seasonFromContext(group) ?: 1, 0, null, null, false)
            val show = e.showName.ifBlank { MediaTitleParser.showNameFromGroup(group) ?: "" }
            if (show.isBlank()) Result(ContentType.MOVIE, null, movie, margin)   // sem nome de série: trata como filme
            else Result(ContentType.SERIES, e.copy(showName = show), null, margin)
        }
        ContentType.MOVIE -> Result(ContentType.MOVIE, null, movie, margin)
        ContentType.LIVE -> Result(ContentType.LIVE, null, null, margin)
    }

    /** Compatibilidade: usado pelos testes antigos. */
    fun parseEpisode(title: String) = MediaTitleParser.parseEpisode(title)
}

/** 1ª passada: aprende o tipo predominante de cada grupo com as entradas de alta confiança. */
class GroupProfiler {
    private val counts = HashMap<String, DoubleArray>()

    fun add(e: M3uEntry) {
        val r = ContentClassifier.classify(e, null)
        if (r.margin < 3) return
        val c = counts.getOrPut(e.group.orEmpty()) { DoubleArray(3) }
        c[r.type.ordinal] += 1.0
    }

    fun prior(group: String?): ContentClassifier.GroupPrior? {
        val c = counts[group.orEmpty()] ?: return null
        val n = c.sum()
        if (n == 0.0) return null
        return ContentClassifier.GroupPrior(c[0] / n, c[1] / n, c[2] / n, n.toInt())
    }
}
