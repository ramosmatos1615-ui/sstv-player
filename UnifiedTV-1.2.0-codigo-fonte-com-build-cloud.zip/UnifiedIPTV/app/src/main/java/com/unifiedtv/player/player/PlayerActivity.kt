package com.unifiedtv.player.player

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.unifiedtv.player.AppContainer
import com.unifiedtv.player.UnifiedApp

/**
 * Player ExoPlayer (Media3) integrado. Recebe TODAS as fontes do conteúdo
 * (vindas de listas diferentes) e alterna automaticamente para a próxima
 * fonte se a atual falhar - o usuário nunca precisa trocar de lista.
 */
@UnstableApi
class PlayerActivity : ComponentActivity() {

    data class Source(val url: String, val userAgent: String?, val referer: String?, val name: String)

    companion object {
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_URLS = "urls"
        private const val EXTRA_UAS = "uas"
        private const val EXTRA_REFS = "refs"
        private const val EXTRA_NAMES = "names"
        private const val EXTRA_LIVE = "live"

        fun start(context: Context, title: String, sources: List<Source>, live: Boolean) {
            if (sources.isEmpty()) return
            context.startActivity(Intent(context, PlayerActivity::class.java).apply {
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_URLS, sources.map { it.url }.toTypedArray())
                putExtra(EXTRA_UAS, sources.map { it.userAgent.orEmpty() }.toTypedArray())
                putExtra(EXTRA_REFS, sources.map { it.referer.orEmpty() }.toTypedArray())
                putExtra(EXTRA_NAMES, sources.map { it.name }.toTypedArray())
                putExtra(EXTRA_LIVE, live)
            })
        }
    }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private var sources: List<Source> = emptyList()
    private var current = 0
    private var retriesOnSource = 0
    private var title = ""
    private var live = false
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        live = intent.getBooleanExtra(EXTRA_LIVE, false)
        val urls = intent.getStringArrayExtra(EXTRA_URLS) ?: emptyArray()
        val uas = intent.getStringArrayExtra(EXTRA_UAS) ?: emptyArray()
        val refs = intent.getStringArrayExtra(EXTRA_REFS) ?: emptyArray()
        val names = intent.getStringArrayExtra(EXTRA_NAMES) ?: emptyArray()
        sources = urls.indices.map {
            Source(urls[it], uas.getOrNull(it)?.ifBlank { null }, refs.getOrNull(it)?.ifBlank { null }, names.getOrElse(it) { "Fonte ${it + 1}" })
        }
        current = savedInstanceState?.getInt("current") ?: 0

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            keepScreenOn = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            setShowNextButton(false)
            setShowPreviousButton(false)
        }
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f
            setBackgroundColor(0x99000000.toInt()); setPadding(32, 16, 32, 16)
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(32, 32, 32, 32) })
        setContentView(root)

        initPlayer()
        playSource(current, savedInstanceState?.getLong("position") ?: C.TIME_UNSET)
    }

    private fun initPlayer() {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 2_000, 4_000)
            .build()
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
        player = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .build()
        player.playWhenReady = true
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition(); player.prepare(); return
                }
                if (retriesOnSource < 1 && error.errorCode in setOf(
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED)) {
                    retriesOnSource++; player.prepare(); return
                }
                if (current + 1 < sources.size) {
                    showOverlay("${sources[current].name} falhou. Trocando para ${sources[current + 1].name}…")
                    playSource(current + 1, C.TIME_UNSET)
                } else {
                    showOverlay("Nenhuma fonte disponível (${error.errorCodeName})", sticky = true)
                }
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retriesOnSource = 0
            }
        })
    }

    private fun mediaSourceFactory(src: Source): DefaultMediaSourceFactory {
        val http = (application as UnifiedApp).container.http
        val okFactory = OkHttpDataSource.Factory(http)
            .setUserAgent(src.userAgent ?: AppContainer.USER_AGENT)
            .apply { src.referer?.let { setDefaultRequestProperties(mapOf("Referer" to it)) } }
        return DefaultMediaSourceFactory(DefaultDataSource.Factory(this, okFactory))
    }

    private fun playSource(index: Int, position: Long) {
        if (index !in sources.indices) return
        current = index; retriesOnSource = 0
        val src = sources[index]
        val builder = MediaItem.Builder().setUri(src.url)
        val lower = src.url.lowercase().substringBefore('?')
        when {
            lower.endsWith(".m3u8") || lower.contains("/live/") && !lower.endsWith(".ts") -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            lower.endsWith(".mpd") -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
            lower.endsWith(".ts") -> builder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        if (live) builder.setLiveConfiguration(MediaItem.LiveConfiguration.Builder().setTargetOffsetMs(8_000).build())
        player.setMediaSource(mediaSourceFactory(src).createMediaSource(builder.build()))
        if (position != C.TIME_UNSET && position > 0) player.seekTo(position)
        player.prepare()
        showOverlay(if (sources.size > 1) "$title  •  ${src.name} (${index + 1}/${sources.size})" else title)
    }

    private fun showOverlay(text: String, sticky: Boolean = false) {
        overlay.text = text; overlay.visibility = View.VISIBLE
        overlay.removeCallbacks(hideOverlay)
        if (!sticky) overlay.postDelayed(hideOverlay, 4000)
    }

    /** Controle remoto / teclado: CH+/CH- ou "N" alterna manualmente entre fontes. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_N -> {
                if (sources.size > 1) { playSource((current + 1) % sources.size, C.TIME_UNSET); return true }
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (sources.size > 1) { playSource((current - 1 + sources.size) % sources.size, C.TIME_UNSET); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("current", current)
        outState.putLong("position", if (live) C.TIME_UNSET else player.currentPosition)
    }

    override fun onStart() { super.onStart(); if (::player.isInitialized) player.play() }
    override fun onStop() { super.onStop(); if (::player.isInitialized) player.pause() }
    override fun onDestroy() { super.onDestroy(); player.release() }
}
