package com.unifiedtv.player.ui.series

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.UnifiedEpisode
import com.unifiedtv.player.data.db.UnifiedItem
import com.unifiedtv.player.player.PlayerActivity
import com.unifiedtv.player.ui.common.EmptyState
import com.unifiedtv.player.ui.common.repoFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SeriesViewModel(private val repo: MediaRepository, val key: String) : ViewModel() {
    val item = MutableStateFlow<UnifiedItem?>(null)
    val episodes = MutableStateFlow<List<UnifiedEpisode>?>(null)
    val favorite = repo.isFavorite(key).stateIn(viewModelScope, SharingStarted.Eagerly, false)

    init {
        viewModelScope.launch {
            item.value = repo.item(key)
            episodes.value = runCatching { repo.episodes(key) }.getOrDefault(emptyList())
        }
    }
    fun toggleFavorite() = viewModelScope.launch { repo.setFavorite(key, !favorite.value) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesScreen(seriesKey: String, onBack: () -> Unit) {
    val vm: SeriesViewModel = viewModel(key = seriesKey, factory = repoFactory { SeriesViewModel(it, seriesKey) })
    val item by vm.item.collectAsStateWithLifecycle()
    val episodes by vm.episodes.collectAsStateWithLifecycle()
    val fav by vm.favorite.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val seasons = remember(episodes) { episodes.orEmpty().map { it.season }.distinct() }
    var season by remember(seasons) { mutableStateOf(seasons.firstOrNull() ?: 1) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(item?.title ?: "Série") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
            actions = {
                IconButton(onClick = { vm.toggleFavorite() }) {
                    Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorito")
                }
            }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(item?.logo, null, contentScale = ContentScale.Crop,
                    modifier = Modifier.width(90.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(item?.title.orEmpty(), style = MaterialTheme.typography.titleLarge)
                    Text("${item?.category.orEmpty()} • disponível em ${item?.sourceCount ?: 0} lista(s)",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            when {
                episodes == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                episodes!!.isEmpty() -> EmptyState("Nenhum episódio encontrado nas listas ativas.")
                else -> {
                    LazyRow(contentPadding = PaddingValues(horizontal = 8.dp)) {
                        items(seasons) { s ->
                            FilterChip(selected = s == season, onClick = { season = s },
                                label = { Text("Temporada $s") }, modifier = Modifier.padding(4.dp))
                        }
                    }
                    LazyColumn(contentPadding = PaddingValues(8.dp)) {
                        items(episodes!!.filter { it.season == season }, key = { "${it.season}-${it.episode}" }) { ep ->
                            ListItem(
                                headlineContent = { Text("E${ep.episode.toString().padStart(2, '0')} • ${ep.title}") },
                                supportingContent = { if (ep.sources.size > 1) Text("${ep.sources.size} fontes (failover automático)") },
                                leadingContent = { Icon(Icons.Default.PlayArrow, null) },
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                                    PlayerActivity.start(context, "${item?.title ?: ""} T${ep.season}E${ep.episode}",
                                        ep.sources.map { PlayerActivity.Source(it.url, it.userAgent, it.referer, it.sourceName) }, live = false)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
