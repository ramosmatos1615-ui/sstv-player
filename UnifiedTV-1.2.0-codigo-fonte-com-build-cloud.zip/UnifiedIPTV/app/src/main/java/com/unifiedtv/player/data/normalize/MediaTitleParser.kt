package com.unifiedtv.player.data.normalize

import java.util.Calendar

/**
 * Extrai informações estruturadas de títulos de VOD em listas M3U:
 *  - Episódios: "Dark S01E02", "Dark.S01E02.1080p", "Dark 1x02", "Dark T01 EP02",
 *    "Dark - Temporada 1 Episódio 2", "Dark 1ª Temporada Ep 2", "Dark Ep. 05", "Novela Capítulo 120"
 *  - Filmes: "Matrix (1999)", "Matrix [1999] 4K", "Matrix - 1999 Dublado", "Blade Runner 2049 (2017)"
 *  - Variantes: DUB / LEG / DUAL / NAC + qualidade (4K, FHD, HD, SD)
 */
object MediaTitleParser {

    data class EpisodeInfo(
        val showName: String,      // pode ser vazio se o título não traz o nome da série
        val season: Int,
        val episode: Int,
        val episodeTitle: String?,
        val year: Int?,
        val strong: Boolean        // padrão explícito (SxxEyy, 1x02, Temporada/Episódio)
    )

    data class MovieInfo(val name: String, val year: Int?)

    private val IC = RegexOption.IGNORE_CASE
    private const val SEP = """[\s\-–—|:.,(\[]"""
    private val maxYear = Calendar.getInstance().get(Calendar.YEAR) + 1

    private val strongPatterns = listOf(
        // S01E02, S1 E2, S01.E02, T01E02, S01 EP02, S01E01E02
        Regex("""^(.*?)$SEP*\b[ST](\d{1,2})\s*[-._]?\s*EP?\s*(\d{1,4})\b(?:E\d{1,4}\b)?(.*)$""", IC),
        // 1x02
        Regex("""^(.*?)$SEP+(\d{1,2})x(\d{1,4})\b(.*)$""", IC),
        // Temporada 1 Episódio 2 / Season 1 Episode 2 / Temp. 1 Cap. 5
        Regex("""^(.*?)$SEP*\b(?:temporada|temp\.?|season)\s*(\d{1,2})\s*[-–|:,.]*\s*(?:epis[oó]dio|episode|ep\.?|cap[ií]tulo|cap\.?|e(?=\d))\s*(\d{1,4})\b(.*)$""", IC),
        // 1ª Temporada Episódio 2 / 2nd Season Ep 3
        Regex("""^(.*?)$SEP*\b(\d{1,2})\s*(?:ª|º|°|a|nd|rd|st|th)?\s*(?:temporada|season)\s*[-–|:,.]*\s*(?:epis[oó]dio|episode|ep\.?|cap[ií]tulo|cap\.?)?\s*(\d{1,4})\b(.*)$""", IC)
    )

    // Ep 05, Episódio 5, Capítulo 120, Chapter 3, E05
    private val weakPattern = Regex(
        """^(.*?)(?:^|$SEP+)(?:(?:epis[oó]dio|episode|ep\.?|cap[ií]tulo|cap\.|chapter)\s*|E(?=\d))(\d{1,4})\b(.*)$""", IC
    )

    private val seasonInContext = Regex("""\b(?:temporada|temp\.?|season|t|s)\s*0*(\d{1,2})\b|\b(\d{1,2})\s*(?:ª|º|°)?\s*temporada\b""", IC)

    private val brackets = Regex("""\[[^\]]*]|\{[^}]*}""")
    private val countryPrefix = Regex("""^\s*(?:[A-Z]{2,3}|VOD|4K|FHD|HD|SD)\s*[|:•»\-]+\s*""")
    private val tagWords = Regex(
        """\b(?:dublado|dublada|dub|dublagem|legendado|legendada|leg|sub|subbed|dual(?:\s*audio)?|nacional|""" +
            """4k|uhd|2160p|fhd|1080p|hd|720p|sd|480p|hdr10?|hdr|dv|h\.?26[45]|hevc|x26[45]|web[- ]?dl|webrip|""" +
            """bluray|blu-ray|brrip|dvdrip|hdtv|remux|imax|cam|completo|completa|full)\b""", IC
    )
    private val emptyParens = Regex("""\(\s*\)""")
    private val spaces = Regex("""\s+""")

    private fun yearRegex() = Regex("""(?:^|[\s(\[\-–.])((?:19[0-9]|20[0-9])\d)(?=$|[\s)\]\-–.,])""")

    /** "Dark.S01E01.1080p.WEB" -> "Dark S01E01 1080p WEB" */
    fun prepare(raw: String): String {
        var t = raw.trim()
        val dots = t.count { it == '.' || it == '_' }
        if (dots >= 2 && dots > t.count { it == ' ' }) t = t.replace('.', ' ').replace('_', ' ')
        return spaces.replace(t, " ").trim()
    }

    fun detectVariant(vararg texts: String?): String? {
        val all = TextNormalizer.stripAccents(texts.filterNotNull().joinToString(" ")).lowercase()
        val audio = when {
            Regex("""\bdual\b""").containsMatchIn(all) -> "DUAL"
            Regex("""\b(dublado|dublada|dub|dublagem)\b|\[d]|\(d\)""").containsMatchIn(all) -> "DUB"
            Regex("""\b(legendado|legendada|leg|sub|subbed)\b|\[l]|\(l\)""").containsMatchIn(all) -> "LEG"
            Regex("""\bnacional\b""").containsMatchIn(all) -> "NAC"
            else -> null
        }
        val quality = when {
            Regex("""\b(4k|uhd|2160p)\b""").containsMatchIn(all) -> "4K"
            Regex("""\b(fhd|1080p)\b""").containsMatchIn(all) -> "FHD"
            Regex("""\b(hd|720p)\b""").containsMatchIn(all) -> "HD"
            Regex("""\b(sd|480p)\b""").containsMatchIn(all) -> "SD"
            else -> null
        }
        return listOfNotNull(audio, quality).joinToString(" • ").ifEmpty { null }
    }

    /** Nome limpo: sem prefixo de país, tags, qualidade, idioma e ano. */
    fun cleanName(raw: String): String {
        var t = prepare(raw)
        t = brackets.replace(t, " ")
        t = countryPrefix.replace(t, "")
        t = tagWords.replace(t, " ")
        t = Regex("""\((?:d|l)\)""", IC).replace(t, " ")
        t = emptyParens.replace(t, " ")
        t = spaces.replace(t, " ").trim().trim('-', '–', '|', ':', '.', ',', '(', ' ').trim()
        return t
    }

    fun extractYear(raw: String): Int? =
        yearRegex().findAll(raw).map { it.groupValues[1].toInt() }.lastOrNull { it in 1900..maxYear }

    fun parseMovie(raw: String): MovieInfo {
        val prepared = prepare(raw)
        val cleaned = cleanName(prepared)
        val matches = yearRegex().findAll(cleaned).filter { it.groupValues[1].toInt() in 1900..maxYear }.toList()
        val last = matches.lastOrNull() ?: return MovieInfo(cleaned.ifEmpty { raw.trim() }, null)
        val year = last.groupValues[1].toInt()
        val g = last.groups[1]!!.range
        val without = (cleaned.substring(0, g.first) + cleaned.substring(g.last + 1))
            .let { emptyParens.replace(it, " ") }
            .let { spaces.replace(it, " ").trim().trim('-', '–', '(', ')', ' ', ',', '.') }
        // "1917", "2012": o ano é o próprio nome do filme
        return if (without.isEmpty()) MovieInfo(cleaned, null) else MovieInfo(without, year)
    }

    fun parseEpisode(rawTitle: String, group: String? = null): EpisodeInfo? {
        val t = prepare(brackets.replace(rawTitle, " "))
        for (rx in strongPatterns) {
            val m = rx.find(t) ?: continue
            return build(m.groupValues[1], m.groupValues[2].toInt(), m.groupValues[3].toInt(), m.groupValues[4], true)
        }
        val w = weakPattern.find(t) ?: return null
        val season = seasonFromContext(w.groupValues[1]) ?: seasonFromContext(group) ?: 1
        val show = Regex("""$SEP*\b(?:temporada|temp\.?|season)\s*\d{1,2}\b|\b\d{1,2}\s*(?:ª|º|°)?\s*temporada\b""", IC)
            .replace(w.groupValues[1], " ")
        return build(show, season, w.groupValues[2].toInt(), w.groupValues[3], false)
    }

    fun seasonFromContext(text: String?): Int? {
        if (text.isNullOrBlank()) return null
        val m = seasonInContext.find(TextNormalizer.stripAccents(text)) ?: return null
        return (m.groupValues[1].ifEmpty { m.groupValues[2] }).toIntOrNull()
    }

    private fun build(showRaw: String, season: Int, episode: Int, tail: String, strong: Boolean): EpisodeInfo {
        val year = extractYear(showRaw)
        var show = cleanName(showRaw)
        if (year != null) show = spaces.replace(show.replace(Regex("""\(?\b$year\b\)?"""), " "), " ").trim().trim('-', '–', ' ')
        val epTitle = cleanName(tail).trim('-', '–', ':', '|', ' ').takeIf { it.length >= 2 && !it.all { c -> c.isDigit() } }
        return EpisodeInfo(show, season, episode, epTitle, year, strong)
    }

    private val genericGroup = Regex(
        """^(?:series?|s[eé]ries?|temporadas?|seasons?|temp\.?\s*\d+|temporada\s*\d+|season\s*\d+|\d+\s*ª?\s*temporada|""" +
            """vod|filmes?|movies?|novelas?|animes?|doramas?|desenhos?|infantil|kids|dublad[oa]s?|legendad[oa]s?|""" +
            """netflix|amazon|prime(?:\s*video)?|hbo(?:\s*max)?|max|disney\+?|apple(?:\s*tv\+?)?|globoplay|paramount\+?|star\+?|""" +
            """[a-z]{2}|4k|fhd|hd|sd|uhd|lancamentos?|\d+)$""", IC
    )

    /** Tenta descobrir o nome da série pelo grupo: "Séries | Breaking Bad - Temporada 2" -> "Breaking Bad". */
    fun showNameFromGroup(group: String?): String? {
        if (group.isNullOrBlank()) return null
        val parts = group.split(Regex("""\s*[|•»:/]\s*|\s+[-–—]\s+"""))
            .map { cleanName(it).replace(Regex("""\b(?:temporada|temp\.?|season)\s*\d{1,2}\b|\b\d{1,2}\s*ª?\s*temporada\b""", IC), " ").trim() }
            .map { spaces.replace(it, " ").trim() }
            .filter { it.isNotEmpty() && !genericGroup.matches(TextNormalizer.stripAccents(it)) }
        return parts.lastOrNull()
    }
}
