package com.unifiedtv.player.data.normalize

import com.unifiedtv.player.data.db.ContentType
import java.text.Normalizer

/**
 * Gera chaves estáveis para mesclar o mesmo conteúdo vindo de listas diferentes.
 * Ex.: "BR | ESPN HD", "[BR] ESPN FHD" e "ESPN (Backup)" -> "L:espn"
 */
object TextNormalizer {
    private val diacritics = Regex("\\p{Mn}+")
    private val brackets = Regex("""\[[^\]]*]|\{[^}]*}""")
    private val countryPrefix = Regex("""^\s*(?:[A-Z]{2,3}|VIP|VOD|24/7|24H)\s*[|:•»\-]+\s*""")
    private val pipePrefix = Regex("""^[^|]{1,12}\|\s*""")
    private val quality = Regex(
        """\b(?:fhd|uhd|hd|sd|lq|hq|4k|8k|h\.?265|hevc|h\.?264|1080p?|720p?|480p?|2160p?|hdr10?|dv|""" +
            """50fps|60fps|fps|backup|alt|alternativo|legendado|leg|dublado|dub|dual|audio|multi|""" +
            """vip|plus|premium|raw|nacional|\*+|ᴴᴰ|ᶠᴴᴰ|ᵁᴴᴰ|ˢᴰ)\b""",
        RegexOption.IGNORE_CASE
    )
    private val yearRegex = Regex("""(?:\(|\[|\s|^)((?:19|20)\d{2})(?:\)|]|\s|$)""")
    private val nonAlnum = Regex("""[^a-z0-9]+""")
    private val spaces = Regex("""\s+""")

    fun stripAccents(s: String): String =
        diacritics.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "")

    /** Título limpo para exibição (sem prefixos de país e tags entre colchetes). */
    fun displayTitle(raw: String): String {
        var t = raw.trim()
        t = brackets.replace(t, " ")
        t = countryPrefix.replace(t, "")
        return spaces.replace(t, " ").trim().ifEmpty { raw.trim() }
    }

    fun extractYear(raw: String): String? = yearRegex.find(raw)?.groupValues?.get(1)

    fun baseKey(raw: String): String {
        var t = raw
        t = brackets.replace(t, " ")
        t = countryPrefix.replace(t, "")
        if (t.contains('|')) t = pipePrefix.replace(t, "")
        t = stripAccents(t).lowercase()
        t = t.replace("+", " plus ").replace("&", " e ")
        t = Regex("""\((?!(?:19|20)\d{2}\))[^)]*\)""").replace(t, " ") // remove (Backup), (Alt) mas mantém (1999)
        t = quality.replace(t, " ")
        t = nonAlnum.replace(t, " ")
        return spaces.replace(t, " ").trim()
    }

    fun contentKey(type: ContentType, title: String): String {
        val prefix = when (type) { ContentType.LIVE -> "L:"; ContentType.MOVIE -> "M:"; ContentType.SERIES -> "S:" }
        var base = baseKey(title)
        if (type != ContentType.LIVE) {
            val year = extractYear(title)
            base = base.replace(Regex("""\b(?:19|20)\d{2}\b"""), " ").let { spaces.replace(it, " ").trim() }
            if (year != null) base = "$base $year"
        }
        if (base.isEmpty()) base = stripAccents(title).lowercase().trim()
        return prefix + base
    }

    /** Chaves para filmes/séries a partir do nome já limpo e do ano: ("M:matrix 1999", "matrix"). */
    fun vodKeys(type: ContentType, name: String, year: Int?): Pair<String, String> {
        val prefix = if (type == ContentType.MOVIE) "M:" else "S:"
        var base = baseKey(name).ifEmpty { stripAccents(name).lowercase().trim() }
        if (year != null) base = spaces.replace(base.replace(Regex("""\b$year\b"""), " "), " ").trim().ifEmpty { base }
        return (prefix + base + (year?.let { " $it" } ?: "")) to base
    }

    /** Converte o texto do usuário em consulta FTS4 por prefixo: "home ara" -> "home* ara*" */
    fun ftsQuery(input: String): String? {
        val terms = stripAccents(input).lowercase()
            .split(Regex("""[^a-z0-9]+""")).filter { it.isNotBlank() }
        if (terms.isEmpty()) return null
        return terms.joinToString(" ") { "$it*" }
    }
}
