package com.unifiedtv.player.data

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.unifiedtv.player.data.db.*
import com.unifiedtv.player.data.normalize.TextNormalizer
import com.unifiedtv.player.data.sync.SyncManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first

const val FAVORITES = "★ Favoritos"

data class UnifiedEpisode(val season: Int, val episode: Int, val title: String, val logo: String?, val sources: List<EpisodeSource>)

class MediaRepository(private val db: AppDatabase, val sync: SyncManager) {
    private val media = db.mediaDao()
    private val playlists = db.playlistDao()
    private val config = PagingConfig(pageSize = 60, prefetchDistance = 120, enablePlaceholders = false)



    fun categories(type: ContentType) = media.observeCategories(type)

    fun items(type: ContentType, category: String?): Flow<PagingData<UnifiedItem>> =
        if (category == FAVORITES) Pager(config) { media.pageFavorites(type) }.flow
        else Pager(config) { media.pageItems(type, category) }.flow

    fun search(text: String, type: ContentType?): Flow<PagingData<UnifiedItem>> {
        val q = TextNormalizer.ftsQuery(text) ?: return emptyFlow()
        return Pager(config) { media.search(q, type) }.flow
    }

    suspend fun sources(contentKey: String) = media.sourcesFor(contentKey)
    suspend fun item(contentKey: String) = media.item(contentKey)
    suspend fun findLiveChannel(network: String): UnifiedItem? {
        val name = network.trim()
        media.findLiveChannel(name)?.let { return it }
        val fallback = name.replace("+", "").trim()
        if (fallback.isNotBlank() && fallback != name) return media.findLiveChannel(fallback)
        return null
    }

    suspend fun episodes(seriesKey: String): List<UnifiedEpisode> {
        sync.ensureXtreamEpisodes(seriesKey)
        return media.episodesFor(seriesKey)
            .groupBy { it.season to it.episode }
            .map { (k, list) -> UnifiedEpisode(k.first, k.second, list.first().title, list.firstNotNullOfOrNull { it.logo }, list) }
            .sortedWith(compareBy({ it.season }, { it.episode }))
    }

    fun isFavorite(key: String) = media.observeIsFavorite(key)
    suspend fun setFavorite(key: String, fav: Boolean) =
        if (fav) media.addFavorite(FavoriteEntity(key)) else media.removeFavorite(key)

    suspend fun toggleFavorite(key: String): Boolean {
        val fav = isFavorite(key).first()
        setFavorite(key, !fav)
        return !fav
    }

    // ---- listas
    fun observePlaylists() = playlists.observeAll()

    suspend fun addPlaylist(name: String, type: SourceType, url: String, user: String?, pass: String?): Long {
        val id = playlists.insert(PlaylistEntity(name = name, type = type, url = url.trim(),
            username = user?.trim(), password = pass?.trim(), priority = playlists.nextPriority()))
        playlists.get(id)?.let { sync.syncOne(it) }
        return id
    }

    suspend fun setEnabled(p: PlaylistEntity, enabled: Boolean) = playlists.update(p.copy(enabled = enabled))

    suspend fun move(p: PlaylistEntity, up: Boolean) {
        val all = playlists.getAll().toMutableList()
        val i = all.indexOfFirst { it.id == p.id }
        val j = if (up) i - 1 else i + 1
        if (i < 0 || j !in all.indices) return
        java.util.Collections.swap(all, i, j)
        all.forEachIndexed { idx, pl -> if (pl.priority != idx) playlists.update(pl.copy(priority = idx)) }
    }

    suspend fun delete(p: PlaylistEntity) {
        media.deleteStreamsOf(p.id); media.deleteEpisodesOf(p.id); playlists.delete(p); sync.deleteCache(p.id)
    }

    suspend fun refresh(p: PlaylistEntity) = sync.syncOne(p)
}
