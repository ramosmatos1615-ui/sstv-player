package com.unifiedtv.player.data.sync

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.room.withTransaction
import com.unifiedtv.player.data.db.*
import com.unifiedtv.player.data.normalize.CategoryNormalizer
import com.unifiedtv.player.data.normalize.ContentClassifier
import com.unifiedtv.player.data.normalize.GroupProfiler
import com.unifiedtv.player.data.normalize.MediaTitleParser
import com.unifiedtv.player.data.normalize.TextNormalizer
import com.unifiedtv.player.data.parser.M3uParser
import com.unifiedtv.player.data.remote.XtreamClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader

data class SyncState(
    val running: Set<Long> = emptySet(),
    val progress: Map<Long, Int> = emptyMap(),
    val lastMessage: String? = null
) { val isRunning get() = running.isNotEmpty() }

/**
 * Carrega TODAS as listas habilitadas em paralelo e grava no cache local (Room).
 * Usa "gerações": os dados novos são inseridos enquanto os antigos continuam
 * visíveis; ao final, a geração anterior é apagada. A interface nunca fica vazia.
 */
class SyncManager(
    private val context: Context,
    private val db: AppDatabase,
    private val http: OkHttpClient
) {
    companion object {
        const val CACHE_TTL_MS = 12L * 60 * 60 * 1000 // 12 horas
        private const val BATCH = 2000
        private const val TAG = "SyncManager"
    }

    private val _state = MutableStateFlow(SyncState())
    val state: StateFlow<SyncState> = _state
    private val parallel = Semaphore(3)
    private val playlistDao = db.playlistDao()
    private val mediaDao = db.mediaDao()

    suspend fun syncAll(force: Boolean) = coroutineScope {
        val now = System.currentTimeMillis()
        playlistDao.getAll()
            .filter { it.enabled && (force || now - it.lastSync > CACHE_TTL_MS || it.itemCount == 0) }
            .map { p -> async(Dispatchers.IO) { parallel.withPermit { syncOne(p) } } }
            .awaitAll()
    }

    suspend fun syncOne(p: PlaylistEntity) = withContext(Dispatchers.IO) {
        if (p.id in _state.value.running) return@withContext
        _state.update { it.copy(running = it.running + p.id, progress = it.progress + (p.id to 0)) }
        val gen = System.currentTimeMillis()
        try {
            val count = when (p.type) {
                SourceType.M3U -> syncM3u(p, gen)
                SourceType.XTREAM -> syncXtream(p, gen)
            }
            db.withTransaction {
                mediaDao.deleteOldStreams(p.id, gen)
                mediaDao.deleteOldEpisodes(p.id, gen)
                mediaDao.reconcileEpisodeKeys()
                mediaDao.reconcileStreamKeys()
            }
            playlistDao.get(p.id)?.let {
                playlistDao.update(it.copy(lastSync = System.currentTimeMillis(), itemCount = count,
                    lastError = null, generation = gen))
            }
            _state.update { it.copy(lastMessage = "${p.name}: $count itens carregados") }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Falha ao sincronizar ${p.name}", e)
            // mantém o cache anterior; remove apenas o que foi parcialmente inserido
            mediaDao.deleteOldStreams(p.id, p.generation)
            mediaDao.deleteOldEpisodes(p.id, p.generation)
            playlistDao.get(p.id)?.let { playlistDao.update(it.copy(lastError = e.message ?: e.javaClass.simpleName)) }
            _state.update { it.copy(lastMessage = "${p.name}: erro - ${e.message}") }
        } finally {
            _state.update { it.copy(running = it.running - p.id, progress = it.progress - p.id) }
        }
    }

    private fun report(pid: Long, n: Int) = _state.update { it.copy(progress = it.progress + (pid to n)) }

    // ------------------------------------------------------------------ M3U
    private fun cacheFile(pid: Long) = File(File(context.filesDir, "m3u").apply { mkdirs() }, "$pid.m3u")

    fun deleteCache(pid: Long) { cacheFile(pid).delete() }

    /**
     * Baixa (ou copia) a lista para um arquivo local. Se a rede falhar, reutiliza a
     * última cópia baixada - a lista continua funcionando offline.
     */
    private fun materialize(p: PlaylistEntity): File {
        val target = cacheFile(p.id)
        val tmp = File(target.parentFile, "${p.id}.tmp")
        try {
            val input = if (p.url.startsWith("content://") || p.url.startsWith("file://")) {
                context.contentResolver.openInputStream(Uri.parse(p.url)) ?: throw IOException("Não foi possível abrir o arquivo")
            } else {
                val resp = http.newCall(Request.Builder().url(p.url).build()).execute()
                if (!resp.isSuccessful) { resp.close(); throw IOException("HTTP ${resp.code}") }
                resp.body?.byteStream() ?: throw IOException("Resposta vazia")
            }
            input.use { ins -> tmp.outputStream().use { ins.copyTo(it, 64 * 1024) } }
            if (tmp.length() == 0L) throw IOException("Lista vazia")
            if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
        } catch (e: IOException) {
            tmp.delete()
            if (target.exists() && target.length() > 0) {
                Log.w(TAG, "Usando cópia local de ${p.name}", e); return target
            }
            throw e
        }
        return target
    }

    private fun reader(f: File) = BufferedReader(InputStreamReader(f.inputStream(), Charsets.UTF_8), 64 * 1024)

    private suspend fun syncM3u(p: PlaylistEntity, gen: Long): Int {
        val file = materialize(p)

        // 1ª passada: perfil de cada grupo (tipo predominante entre entradas de alta confiança)
        val profiler = GroupProfiler()
        reader(file).use { r -> for (e in M3uParser.entries(r)) { currentCoroutineContext().ensureActive(); profiler.add(e) } }

        // 2ª passada: classificação final + gravação em lotes
        val streams = ArrayList<StreamEntity>(BATCH)
        val episodes = ArrayList<EpisodeEntity>(BATCH)
        val shows = LinkedHashMap<String, StreamEntity>()
        val autoEpisode = HashMap<String, Int>()
        var count = 0
        var index = 0

        suspend fun flush() {
            if (streams.isEmpty() && episodes.isEmpty()) return
            val s = ArrayList(streams); val e = ArrayList(episodes)
            streams.clear(); episodes.clear()
            db.withTransaction {
                if (s.isNotEmpty()) mediaDao.insertStreams(s)
                if (e.isNotEmpty()) mediaDao.insertEpisodes(e)
            }
            report(p.id, count)
        }

        reader(file).use { r ->
            for (entry in M3uParser.entries(r)) {
                currentCoroutineContext().ensureActive()
                val res = ContentClassifier.classify(entry, profiler.prior(entry.group))
                val logo = entry.attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                val variant = MediaTitleParser.detectVariant(entry.title, entry.group)
                count++
                when (res.type) {
                    ContentType.SERIES -> {
                        val ep = res.episode!!
                        val (seriesKey, base) = TextNormalizer.vodKeys(ContentType.SERIES, ep.showName, ep.year)
                        val category = CategoryNormalizer.normalize(ContentType.SERIES, entry.group, base)
                        val show = shows[seriesKey]
                        if (show == null) {
                            shows[seriesKey] = StreamEntity(
                                playlistId = p.id, generation = gen, type = ContentType.SERIES,
                                contentKey = seriesKey, baseKey = base, title = ep.showName, category = category,
                                originalGroup = entry.group.orEmpty(), logo = logo, url = "", sortIndex = index++
                            )
                        } else if (show.logo == null && logo != null) shows[seriesKey] = show.copy(logo = logo)
                        val epNum = if (ep.episode > 0) ep.episode
                            else (autoEpisode.getOrDefault("$seriesKey/${ep.season}", 0) + 1).also { autoEpisode["$seriesKey/${ep.season}"] = it }
                        episodes += EpisodeEntity(
                            playlistId = p.id, generation = gen, seriesKey = seriesKey,
                            season = ep.season, episode = epNum,
                            title = ep.episodeTitle ?: "Episódio $epNum", url = entry.url, logo = logo,
                            userAgent = entry.userAgent, referer = entry.referer, variant = variant
                        )
                    }
                    ContentType.MOVIE -> {
                        val m = res.movie ?: MediaTitleParser.parseMovie(entry.title)
                        val (key, base) = TextNormalizer.vodKeys(ContentType.MOVIE, m.name, m.year)
                        streams += StreamEntity(
                            playlistId = p.id, generation = gen, type = ContentType.MOVIE,
                            contentKey = key, baseKey = base,
                            title = if (m.year != null) "${m.name} (${m.year})" else m.name,
                            category = CategoryNormalizer.normalize(ContentType.MOVIE, entry.group),
                            originalGroup = entry.group.orEmpty(), logo = logo, url = entry.url,
                            userAgent = entry.userAgent, referer = entry.referer, sortIndex = index++, variant = variant
                        )
                    }
                    ContentType.LIVE -> {
                        val key = TextNormalizer.contentKey(ContentType.LIVE, entry.title)
                        streams += StreamEntity(
                            playlistId = p.id, generation = gen, type = ContentType.LIVE,
                            contentKey = key, baseKey = key.removePrefix("L:"),
                            title = TextNormalizer.displayTitle(entry.title),
                            category = CategoryNormalizer.normalize(ContentType.LIVE, entry.group),
                            originalGroup = entry.group.orEmpty(), logo = logo, url = entry.url,
                            epgId = entry.attrs["tvg-id"], userAgent = entry.userAgent, referer = entry.referer,
                            sortIndex = index++
                        )
                    }
                }
                if (streams.size >= BATCH || episodes.size >= BATCH) flush()
            }
        }
        flush()
        if (shows.isNotEmpty()) shows.values.chunked(BATCH).forEach { mediaDao.insertStreams(it) }
        if (count == 0) throw IOException("Lista vazia ou formato inválido")
        return count
    }

    // ------------------------------------------------------------------ Xtream
    private suspend fun syncXtream(p: PlaylistEntity, gen: Long): Int {
        val x = XtreamClient(http, p.url, p.username.orEmpty(), p.password.orEmpty())
        x.authenticate()
        var count = 0
        var index = 0
        val buffer = ArrayList<StreamEntity>(BATCH)

        suspend fun flush() {
            if (buffer.isEmpty()) return
            val copy = ArrayList(buffer); buffer.clear()
            mediaDao.insertStreams(copy)
            report(p.id, count)
        }

        suspend fun section(type: ContentType, catAction: String, fetch: ((Map<String, String?>) -> Unit) -> Unit) {
            val cats = runCatching { x.categories(catAction) }.getOrDefault(emptyMap())
            val local = ArrayList<StreamEntity>()
            fetch { m ->
                val name = m["name"]?.trim().orEmpty()
                if (name.isEmpty()) return@fetch
                val group = cats[m["category_id"]].orEmpty()
                val (url, seriesRef) = when (type) {
                    ContentType.LIVE -> x.liveUrl(m["stream_id"] ?: return@fetch) to null
                    ContentType.MOVIE -> x.movieUrl(m["stream_id"] ?: return@fetch, m["container_extension"]) to null
                    ContentType.SERIES -> "" to (m["series_id"] ?: return@fetch)
                }
                val logo = (m["stream_icon"] ?: m["cover"])?.takeIf { it.isNotBlank() }
                val keys: Pair<String, String>
                val title: String
                if (type == ContentType.LIVE) {
                    val k = TextNormalizer.contentKey(type, name)
                    keys = k to k.removePrefix("L:"); title = TextNormalizer.displayTitle(name)
                } else {
                    val mi = MediaTitleParser.parseMovie(name)
                    val year = mi.year ?: m["year"]?.take(4)?.toIntOrNull()
                        ?: (m["releaseDate"] ?: m["release_date"])?.take(4)?.toIntOrNull()
                    keys = TextNormalizer.vodKeys(type, mi.name, year)
                    title = if (year != null && type == ContentType.MOVIE) "${mi.name} ($year)" else mi.name
                }
                local += StreamEntity(
                    playlistId = p.id, generation = gen, type = type,
                    contentKey = keys.first, baseKey = keys.second,
                    variant = if (type == ContentType.LIVE) null else MediaTitleParser.detectVariant(name, group),
                    title = title,
                    category = CategoryNormalizer.normalize(type, group),
                    originalGroup = group, logo = logo, url = url,
                    epgId = m["epg_channel_id"], seriesRef = seriesRef, sortIndex = index++
                )
            }
            for (s in local) {
                currentCoroutineContext().ensureActive()
                buffer += s; count++
                if (buffer.size >= BATCH) flush()
            }
            flush()
        }

        section(ContentType.LIVE, "get_live_categories") { x.liveStreams(it) }
        section(ContentType.MOVIE, "get_vod_categories") { x.vodStreams(it) }
        section(ContentType.SERIES, "get_series_categories") { x.series(it) }
        if (count == 0) throw IOException("Nenhum conteúdo retornado pelo servidor")
        return count
    }

    /** Busca (sob demanda) e guarda em cache os episódios de uma série Xtream. */
    suspend fun ensureXtreamEpisodes(seriesKey: String) = withContext(Dispatchers.IO) {
        val refs = mediaDao.xtreamSeriesRefs(seriesKey)
        coroutineScope {
            refs.map { ref ->
                async {
                    if (mediaDao.countEpisodes(ref.playlistId, seriesKey) > 0) return@async
                    val p = playlistDao.get(ref.playlistId) ?: return@async
                    runCatching {
                        val x = XtreamClient(http, p.url, p.username.orEmpty(), p.password.orEmpty())
                        val eps = x.seriesEpisodes(ref.seriesRef).map {
                            EpisodeEntity(
                                playlistId = p.id, generation = ref.generation, seriesKey = seriesKey,
                                season = it.season, episode = it.episode, title = it.title,
                                url = it.url, logo = it.logo
                            )
                        }
                        if (eps.isNotEmpty()) mediaDao.insertEpisodes(eps)
                    }.onFailure { Log.w(TAG, "Episódios de ${p.name} indisponíveis", it) }
                }
            }.awaitAll()
        }
    }
}
