package com.unifiedtv.player.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.paging.compose.itemKey
import com.unifiedtv.player.data.db.ContentType
import com.unifiedtv.player.ui.common.EmptyState
import com.unifiedtv.player.ui.common.MediaCard
import com.unifiedtv.player.ui.common.playUnified
import com.unifiedtv.player.ui.common.toggleFavorite
import com.unifiedtv.player.ui.common.repoFactory
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onSearch: () -> Unit, onPlaylists: () -> Unit, onSeries: (String) -> Unit) {
    val vm: HomeViewModel = viewModel(factory = repoFactory { HomeViewModel(it) })
    val type by vm.type.collectAsStateWithLifecycle()
    val category by vm.category.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val sync by vm.syncState.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val items = vm.items.collectAsLazyPagingItems()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as com.unifiedtv.player.UnifiedApp

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text("UnifiedTV") },
                    actions = {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Buscar") }
                        IconButton(onClick = { vm.refreshAll() }) { Icon(Icons.Default.Refresh, "Atualizar") }
                        IconButton(onClick = onPlaylists) { Icon(Icons.Default.List, "Listas") }
                    }
                )
                if (sync.isRunning) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    val total = sync.progress.values.sum()
                    Text("Carregando ${sync.running.size} lista(s)… $total itens",
                        style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                }
                val tabs = listOf(ContentType.LIVE to "Ao vivo", ContentType.MOVIE to "Filmes", ContentType.SERIES to "Séries")
                TabRow(selectedTabIndex = tabs.indexOfFirst { it.first == type }) {
                    tabs.forEach { (t, label) ->
                        Tab(selected = t == type, onClick = { vm.selectType(t) }, text = { Text(label) })
                    }
                }
                LazyRow(contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)) {
                    item {
                        FilterChip(selected = category == null, onClick = { vm.selectCategory(null) },
                            label = { Text("Todos (${categories.sumOf { it.count }})") }, modifier = Modifier.padding(4.dp))
                    }
                    item {
                        FilterChip(selected = category == HomeViewModel.FAV, onClick = { vm.selectCategory(HomeViewModel.FAV) },
                            label = { Text(HomeViewModel.FAV) }, modifier = Modifier.padding(4.dp))
                    }
                    items(categories, key = { it.category }) { c ->
                        FilterChip(selected = category == c.category, onClick = { vm.selectCategory(c.category) },
                            label = { Text("${c.category} (${c.count})") }, modifier = Modifier.padding(4.dp))
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            SportsAgenda(app.container.sports) { network ->
                val channel = vm.repo.findLiveChannel(network)
                if (channel == null) {
                    android.widget.Toast.makeText(context, "Canal $network não encontrado nas listas IPTV ativas", android.widget.Toast.LENGTH_LONG).show()
                } else {
                    playUnified(context, vm.repo, channel)
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f)) {
            when {
                playlists?.isEmpty() == true -> EmptyState("Nenhuma lista cadastrada.\nAdicione listas M3U ou Xtream - todas serão mescladas aqui.") {
                    Button(onClick = onPlaylists) { Text("Adicionar lista") }
                }
                items.itemCount == 0 && items.loadState.refresh is LoadState.NotLoading ->
                    EmptyState(if (sync.isRunning) "Carregando listas…" else "Nada nesta categoria.")
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (type == ContentType.LIVE) 130.dp else 115.dp),
                    contentPadding = PaddingValues(6.dp), modifier = Modifier.fillMaxSize()
                ) {
                    items(count = items.itemCount, key = items.itemKey { it.contentKey }) { i ->
                        val item = items[i] ?: return@items
                        MediaCard(item, onLongClick = { scope.launch { toggleFavorite(context, vm.repo, item) } }) {
                            if (item.type == ContentType.SERIES) onSeries(item.contentKey)
                            else scope.launch { playUnified(context, vm.repo, item) }
                        }
                    }
                }
            }
            }
        }
    }
}
