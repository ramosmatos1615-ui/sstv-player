package com.unifiedtv.player.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.unifiedtv.player.data.sports.SportsGame
import com.unifiedtv.player.data.sports.SportsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Composable
fun SportsAgenda(
    sports: SportsRepository,
    onOpenChannel: suspend (String) -> Unit
) {
    var games by remember { mutableStateOf<List<SportsGame>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(sports) {
        while (isActive) {
            runCatching { sports.today() }
                .onSuccess { games = it; failed = false }
                .onFailure { failed = true }
            loading = false
            delay(60_000L)
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("JOGOS DE HOJE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(10.dp))
            Text("• placares e transmissão", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                scope.launch {
                    loading = true
                    runCatching { sports.today() }.onSuccess { games = it; failed = false }.onFailure { failed = true }
                    loading = false
                }
            }) { Text("Atualizar") }
        }
        when {
            loading && games.isEmpty() -> LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
            games.isEmpty() -> Text(
                if (failed) "Não foi possível carregar a agenda esportiva agora." else "Nenhum jogo encontrado para hoje nas competições disponíveis.",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            else -> LazyRow(
                contentPadding = PaddingValues(horizontal = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(games, key = { it.id }) { game ->
                    SportsGameCard(game) { network -> scope.launch { onOpenChannel(network) } }
                }
            }
        }
    }
}

@Composable
private fun SportsGameCard(game: SportsGame, onNetworkClick: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val borderColor = if (focused) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = .35f)
    Column(
        Modifier.width(310.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))
            .border(if (focused) 2.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = game.networks.isNotEmpty()) { game.networks.firstOrNull()?.let(onNetworkClick) }
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(game.league, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            if (game.isLive) {
                Text("● AO VIVO", color = Color(0xFFE53935), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            } else {
                Text(game.startTime.ifBlank { game.status }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TeamBlock(game.homeName, game.homeLogo, Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text("${game.homeScore}  ×  ${game.awayScore}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (game.isLive) game.clock else game.status, fontSize = 10.sp, color = if (game.isLive) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            TeamBlock(game.awayName, game.awayLogo, Modifier.weight(1f), alignEnd = true)
        }
        Spacer(Modifier.height(10.dp))
        if (game.networks.isNotEmpty()) {
            Text("ASSISTA NESTE CANAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(5.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                game.networks.take(3).forEach { network ->
                    Button(
                        onClick = { onNetworkClick(network) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(34.dp).weight(1f, fill = false)
                    ) { Text(network, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }
            }
        } else {
            Text("Transmissão não informada pela fonte de placares", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TeamBlock(name: String, logo: String?, modifier: Modifier, alignEnd: Boolean = false) {
    Column(modifier, horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            if (logo != null) AsyncImage(logo, contentDescription = name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(3.dp))
            else Text(name.take(3).uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
