package com.unifiedtv.player.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [PlaylistEntity::class, StreamEntity::class, StreamFts::class,
        EpisodeEntity::class, FavoriteEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun mediaDao(): MediaDao

    companion object {
        /** v2: baseKey + variant; força nova sincronização com o classificador melhorado. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE streams ADD COLUMN baseKey TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE streams ADD COLUMN variant TEXT")
                db.execSQL("ALTER TABLE episodes ADD COLUMN variant TEXT")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_streams_type_baseKey ON streams (type, baseKey)")
                db.execSQL("UPDATE playlists SET lastSync = 0")
            }
        }

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "unifiedtv.db")
                .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()
                .build()
    }
}
