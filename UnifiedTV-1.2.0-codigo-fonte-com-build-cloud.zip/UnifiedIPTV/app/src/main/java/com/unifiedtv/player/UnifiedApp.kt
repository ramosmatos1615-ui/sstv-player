package com.unifiedtv.player

import android.app.Application
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.db.AppDatabase
import com.unifiedtv.player.data.sync.SyncManager
import com.unifiedtv.player.data.sync.SyncWorker
import com.unifiedtv.player.data.sports.SportsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AppContainer(app: Application) {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true).followSslRedirects(true)
        .addInterceptor { chain ->
            val r = chain.request()
            chain.proceed(if (r.header("User-Agent") == null)
                r.newBuilder().header("User-Agent", USER_AGENT).build() else r)
        }
        .build()
    val db = AppDatabase.build(app)
    val syncManager = SyncManager(app, db, http)
    val repository = MediaRepository(db, syncManager)
    val sports = SportsRepository(http)

    companion object { const val USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20" }
}

class UnifiedApp : Application() {
    lateinit var container: AppContainer
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        SyncWorker.schedule(this)
        // Ao abrir: mostra o cache imediatamente e atualiza só listas vencidas (TTL 12h)
        appScope.launch { container.syncManager.syncAll(force = false) }
    }
}
