package com.unifiedtv.player.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unifiedtv.player.UnifiedApp
import com.unifiedtv.player.ui.home.HomeScreen
import com.unifiedtv.player.ui.playlists.PlaylistsScreen
import com.unifiedtv.player.ui.playlists.UnifiedAppHolder
import com.unifiedtv.player.ui.search.SearchScreen
import com.unifiedtv.player.ui.series.SeriesScreen
import com.unifiedtv.player.ui.theme.UnifiedTheme
import java.net.URLDecoder
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        UnifiedAppHolder.app = application as UnifiedApp
        setContent {
            UnifiedTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val nav = rememberNavController()
                    val openSeries: (String) -> Unit = { nav.navigate("series/" + URLEncoder.encode(it, "UTF-8")) }
                    NavHost(nav, startDestination = "home") {
                        composable("home") {
                            HomeScreen(onSearch = { nav.navigate("search") }, onPlaylists = { nav.navigate("playlists") }, onSeries = openSeries)
                        }
                        composable("search") { SearchScreen(onBack = { nav.popBackStack() }, onSeries = openSeries) }
                        composable("playlists") { PlaylistsScreen(onBack = { nav.popBackStack() }) }
                        composable("series/{key}", arguments = listOf(navArgument("key") { type = NavType.StringType })) { e ->
                            val key = URLDecoder.decode(e.arguments?.getString("key").orEmpty(), "UTF-8")
                            SeriesScreen(key, onBack = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
