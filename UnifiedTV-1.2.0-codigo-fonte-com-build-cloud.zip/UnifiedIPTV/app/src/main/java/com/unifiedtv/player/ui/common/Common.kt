package com.unifiedtv.player.ui.common

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import coil.compose.AsyncImage
import com.unifiedtv.player.UnifiedApp
import com.unifiedtv.player.data.MediaRepository
import com.unifiedtv.player.data.db.ContentType
import com.unifiedtv.player.data.db.UnifiedItem
import com.unifiedtv.player.player.PlayerActivity

/** Fábrica simples de ViewModels com acesso ao repositório. */
inline fun <reified VM : ViewModel> repoFactory(crossinline create: (MediaRepository) -> VM) =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
            val app = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as UnifiedApp
            return create(app.container.repository) as T
        }
    }

suspend fun toggleFavorite(context: Context, repo: MediaRepository, item: UnifiedItem) {
    val now = repo.toggleFavorite(item.contentKey)
    Toast.makeText(context, if (now) "Adicionado aos favoritos" else "Removido dos favoritos", Toast.LENGTH_SHORT).show()
}

suspend fun playUnified(context: Context, repo: MediaRepository, item: UnifiedItem) {
    val sources = repo.sources(item.contentKey).map {
        PlayerActivity.Source(it.url, it.userAgent, it.referer, it.sourceName)
    }
    if (sources.isEmpty()) {
        Toast.makeText(context, "Conteúdo indisponível nas listas ativas", Toast.LENGTH_SHORT).show(); return
    }
    PlayerActivity.start(context, item.title, sources, live = item.type == ContentType.LIVE)
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun MediaCard(item: UnifiedItem, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val poster = item.type != ContentType.LIVE
    val scale by androidx.compose.animation.core.animateFloatAsState(if (focused) 1.06f else 1f, label = "focus")
    Column(
        Modifier
            .padding(6.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(3.dp, if (focused) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(if (poster) 2f / 3f else 16f / 10f)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(item.title.take(2).uppercase(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (!item.logo.isNullOrBlank()) {
                AsyncImage(
                    model = item.logo, contentDescription = item.title,
                    contentScale = if (poster) ContentScale.Crop else ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(if (poster) 0.dp else 10.dp)
                )
            }
            if (item.sourceCount > 1) {
                Text(
                    "${item.sourceCount} fontes",
                    fontSize = 10.sp, color = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
        Text(
            item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth().padding(6.dp).heightIn(min = 34.dp)
        )
    }
}

@Composable
fun EmptyState(text: String, action: (@Composable () -> Unit)? = null) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) { Spacer(Modifier.height(16.dp)); action() }
    }
}
