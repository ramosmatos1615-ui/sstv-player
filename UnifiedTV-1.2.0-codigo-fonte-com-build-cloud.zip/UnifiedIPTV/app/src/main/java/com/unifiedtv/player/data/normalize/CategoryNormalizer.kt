package com.unifiedtv.player.data.normalize

import com.unifiedtv.player.data.db.ContentType

/**
 * Converte os group-title de cada provedor (ex.: "BR | ESPORTES HD", "Sports PPV",
 * "⚽ Futebol") em categorias unificadas comuns a todas as listas.
 */
object CategoryNormalizer {

    private class Rule(val name: String, keywords: List<String>) {
        val regex = Regex("""(?:^|[^a-z0-9])(?:${keywords.joinToString("|")})""")
    }

    private val adult = Rule("Adultos", listOf("adult", "xxx", "18\\+", "\\+18", "porn"))

    private val liveRules = listOf(
        adult,
        Rule("Esportes", listOf("sport", "esport", "deport", "futebol", "futbol", "soccer", "espn", "premiere",
            "sportv", "combate", "ufc", "nba", "nfl", "f1", "formula", "dazn", "ppv", "brasileirao", "champions")),
        Rule("Notícias", listOf("news", "noticia", "jornal", "cnn", "globonews")),
        Rule("Infantil", listOf("kid", "infant", "crianc", "desenho", "cartoon", "nick", "disney junior", "discovery kids")),
        Rule("Documentários", listOf("doc", "discovery", "nat ?geo", "history", "animal planet", "ciencia", "science")),
        Rule("Filmes e Séries", listOf("filme", "movie", "cine", "telecine", "hbo", "max", "megapix", "paramount",
            "star channel", "tnt", "space", "warner", "fx", "amc", "series")),
        Rule("Música", listOf("music", "musica", "mtv", "radio", "show")),
        Rule("Religiosos", listOf("relig", "gospel", "catol", "evang", "igreja", "cancao nova")),
        Rule("24 Horas", listOf("24h", "24 ?7", "24 horas")),
        Rule("Abertos", listOf("aberto", "abertos", "globo", "sbt", "record", "band", "redetv", "cultura", "regiona", "local")),
        Rule("Variedades", listOf("variedad", "entret", "lifestyle", "reality", "gnt", "multishow")),
        Rule("Internacionais", listOf("usa", "uk", "portugal", "espanha", "latino", "international", "intern"))
    )

    private val movieRules = listOf(
        adult,
        Rule("Coleções", listOf("coletanea", "colecao", "colecoes", "collection", "saga", "trilogia", "franquia")),
        Rule("Lançamentos", listOf("lancamento", "estreia", "new release", "novidade", "cinema", "recente", "2025", "2026")),
        Rule("4K", listOf("4k", "uhd")),
        Rule("Ação", listOf("acao", "action", "guerra", "war")),
        Rule("Aventura", listOf("aventura", "adventure")),
        Rule("Animação", listOf("anima", "desenho", "cartoon", "infant", "kid", "famil")),
        Rule("Comédia", listOf("comedia", "comedy")),
        Rule("Terror", listOf("terror", "horror")),
        Rule("Suspense", listOf("suspense", "thriller", "misterio", "policial", "crime")),
        Rule("Ficção Científica", listOf("ficcao", "sci ?fi", "fantasia", "fantasy")),
        Rule("Romance", listOf("romance", "romant")),
        Rule("Drama", listOf("drama")),
        Rule("Documentários", listOf("doc")),
        Rule("Nacionais", listOf("nacional", "brasil")),
        Rule("Religiosos", listOf("relig", "gospel", "biblic")),
        Rule("Faroeste", listOf("faroeste", "western")),
        Rule("Musicais e Shows", listOf("music", "show"))
    )

    private val seriesRules = listOf(
        adult,
        Rule("Netflix", listOf("netflix")),
        Rule("Prime Video", listOf("amazon", "prime")),
        Rule("HBO Max", listOf("hbo", "max")),
        Rule("Disney+", listOf("disney", "star ?\\+", "star plus")),
        Rule("Apple TV+", listOf("apple")),
        Rule("Globoplay", listOf("globoplay", "globo")),
        Rule("Paramount+", listOf("paramount")),
        Rule("Novelas", listOf("novela", "telenovela")),
        Rule("Animes", listOf("anime")),
        Rule("Doramas", listOf("dorama", "k ?drama", "corean", "korean")),
        Rule("Infantil", listOf("infant", "kid", "desenho", "cartoon", "anima")),
        Rule("Documentários", listOf("doc")),
        Rule("Reality Shows", listOf("reality")),
        Rule("Legendadas", listOf("legendad"))
    )

    private val cleanup = Regex("""[^\p{L}\p{N}+ ]+""")

    private val genericMovie = Regex("""^(filmes?|movies?|vod|todos( os)? filmes|outros|geral)$""")
    private val genericSeries = Regex("""^(series?|séries?|tv shows?|outras?|geral|todas( as)? series)$""")

    /** @param showBase baseKey da série (para não criar uma categoria por série). */
    fun normalize(type: ContentType, groupTitle: String?, showBase: String? = null): String {
        val raw = groupTitle?.trim().orEmpty()
        if (raw.isEmpty()) return "Outros"
        val probe = " " + TextNormalizer.stripAccents(raw).lowercase()
            .replace(Regex("""[|_\-:\[\]()]+"""), " ") + " "
        val rules = when (type) {
            ContentType.LIVE -> liveRules
            ContentType.MOVIE -> movieRules
            ContentType.SERIES -> seriesRules
        }
        rules.firstOrNull { it.regex.containsMatchIn(probe) }?.let { return it.name }
        val fb = fallback(raw)
        val fbProbe = TextNormalizer.stripAccents(fb).lowercase()
        return when (type) {
            ContentType.MOVIE -> if (genericMovie.matches(fbProbe) || fb == "Outros") "Outros Filmes" else fb
            ContentType.SERIES -> when {
                genericSeries.matches(fbProbe) || fb == "Outros" -> "Outras Séries"
                MediaTitleParser.seasonFromContext(raw) != null -> "Outras Séries"
                showBase != null && showBase.isNotEmpty() && TextNormalizer.baseKey(fb).isNotEmpty() &&
                    (TextNormalizer.baseKey(fb).contains(showBase) || showBase.contains(TextNormalizer.baseKey(fb))) -> "Outras Séries"
                else -> fb
            }
            ContentType.LIVE -> fb
        }
    }

    /** Sem regra conhecida: usa o próprio grupo limpo ("BR | REDE XYZ" -> "Rede Xyz"). */
    private fun fallback(raw: String): String {
        var t = TextNormalizer.displayTitle(raw)
        if (t.contains('|')) t = t.substringAfterLast('|')
        t = cleanup.replace(t, " ").replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "Outros"
        return t.lowercase().split(' ').joinToString(" ") { w ->
            if (w.length <= 2 && w.all { it.isLetter() }) w.uppercase() else w.replaceFirstChar { it.titlecase() }
        }
    }
}
