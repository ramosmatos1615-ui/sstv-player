package com.unifiedtv.player.data.db

import androidx.room.*

enum class SourceType { M3U, XTREAM }
enum class ContentType { LIVE, MOVIE, SERIES }

/** Uma lista de reprodução cadastrada (M3U por URL/arquivo ou conta Xtream Codes). */
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: SourceType,
    val url: String,
    val username: String? = null,
    val password: String? = null,
    val enabled: Boolean = true,
    /** Menor = preferida quando o mesmo conteúdo existe em várias listas. */
    val priority: Int = 0,
    val lastSync: Long = 0,
    val itemCount: Int = 0,
    val lastError: String? = null,
    val generation: Long = 0
)

/**
 * Cada linha é um stream vindo de UMA lista. Streams de listas diferentes que
 * representam o mesmo conteúdo compartilham o mesmo [contentKey] e são mesclados
 * na interface (com failover automático entre fontes).
 */
@Entity(
    tableName = "streams",
    indices = [
        Index("contentKey"), Index("playlistId"),
        Index(value = ["type", "category"]), Index(value = ["type", "title"]), Index(value = ["type", "baseKey"])
    ]
)
data class StreamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val generation: Long,
    val type: ContentType,
    val contentKey: String,
    val title: String,
    val category: String,
    val originalGroup: String,
    val logo: String?,
    val url: String,
    val epgId: String? = null,
    val userAgent: String? = null,
    val referer: String? = null,
    /** series_id do Xtream (episódios carregados sob demanda). */
    val seriesRef: String? = null,
    val sortIndex: Int = 0,
    /** Nome normalizado SEM ano – usado para unir "Matrix" e "Matrix (1999)" entre listas. */
    @ColumnInfo(defaultValue = "") val baseKey: String = "",
    /** Variante da fonte: "DUB • 4K", "LEG", "DUAL • FHD"… */
    val variant: String? = null
)

@Fts4(contentEntity = StreamEntity::class, tokenizer = FtsOptions.TOKENIZER_UNICODE61)
@Entity(tableName = "streams_fts")
data class StreamFts(val title: String)

@Entity(
    tableName = "episodes",
    indices = [Index("seriesKey"), Index(value = ["playlistId", "seriesKey"])]
)
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val generation: Long,
    val seriesKey: String,
    val season: Int,
    val episode: Int,
    val title: String,
    val url: String,
    val logo: String? = null,
    val userAgent: String? = null,
    val referer: String? = null,
    val variant: String? = null
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val contentKey: String,
    val addedAt: Long = System.currentTimeMillis()
)

/** Item unificado exibido na interface (1 por contentKey, N fontes). */
data class UnifiedItem(
    val contentKey: String,
    val type: ContentType,
    val title: String,
    val category: String,
    val logo: String?,
    val sourceCount: Int
)

data class CategoryCount(val category: String, val count: Int)

data class StreamSource(
    val url: String,
    val userAgent: String?,
    val referer: String?,
    val sourceName: String
)

data class EpisodeSource(
    val season: Int,
    val episode: Int,
    val title: String,
    val url: String,
    val logo: String?,
    val userAgent: String?,
    val referer: String?,
    val sourceName: String
)

data class XtreamSeriesRef(
    val playlistId: Long,
    val seriesRef: String,
    val generation: Long
)
