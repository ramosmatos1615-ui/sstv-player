package com.unifiedtv.player.data.db

import androidx.paging.PagingSource
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY priority, id")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY priority, id")
    suspend fun getAll(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun get(id: Long): PlaylistEntity?

    @Insert suspend fun insert(p: PlaylistEntity): Long
    @Update suspend fun update(p: PlaylistEntity)
    @Delete suspend fun delete(p: PlaylistEntity)

    @Query("SELECT COALESCE(MAX(priority), -1) + 1 FROM playlists")
    suspend fun nextPriority(): Int
}

@Dao
interface MediaDao {
    // ---------- escrita (sincronização) ----------
    @Insert suspend fun insertStreams(items: List<StreamEntity>)
    @Insert suspend fun insertEpisodes(items: List<EpisodeEntity>)

    @Query("DELETE FROM streams WHERE playlistId = :pid AND generation <> :gen")
    suspend fun deleteOldStreams(pid: Long, gen: Long)

    @Query("DELETE FROM episodes WHERE playlistId = :pid AND generation <> :gen")
    suspend fun deleteOldEpisodes(pid: Long, gen: Long)

    @Query("DELETE FROM streams WHERE playlistId = :pid")
    suspend fun deleteStreamsOf(pid: Long)

    @Query("DELETE FROM episodes WHERE playlistId = :pid")
    suspend fun deleteEpisodesOf(pid: Long)

    @Query("SELECT COUNT(*) FROM streams WHERE playlistId = :pid")
    suspend fun countStreams(pid: Long): Int

    /**
     * Une títulos sem ano ("S:dark") ao único título com ano de mesmo nome ("S:dark 2017")
     * vindo de qualquer lista. Se houver mais de um ano (remakes), não une.
     */
    @Query("""
        UPDATE episodes SET seriesKey = (
            SELECT MIN(s2.contentKey) FROM streams s2
            WHERE s2.type = 'SERIES' AND s2.baseKey = substr(episodes.seriesKey, 3) AND s2.contentKey <> episodes.seriesKey)
        WHERE (SELECT COUNT(DISTINCT s3.contentKey) FROM streams s3
               WHERE s3.type = 'SERIES' AND s3.baseKey = substr(episodes.seriesKey, 3)
                 AND s3.contentKey <> episodes.seriesKey) = 1
    """)
    suspend fun reconcileEpisodeKeys()

    @Query("""
        UPDATE streams SET contentKey = (
            SELECT MIN(s2.contentKey) FROM streams s2
            WHERE s2.type = streams.type AND s2.baseKey = streams.baseKey AND s2.contentKey <> streams.contentKey)
        WHERE type IN ('MOVIE', 'SERIES') AND baseKey <> ''
          AND contentKey = (CASE type WHEN 'MOVIE' THEN 'M:' ELSE 'S:' END) || baseKey
          AND (SELECT COUNT(DISTINCT s3.contentKey) FROM streams s3
               WHERE s3.type = streams.type AND s3.baseKey = streams.baseKey
                 AND s3.contentKey <> streams.contentKey) = 1
    """)
    suspend fun reconcileStreamKeys()

    // ---------- leitura unificada ----------
    @Query("""
        SELECT s.category AS category, COUNT(DISTINCT s.contentKey) AS count
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND s.type = :type
        GROUP BY s.category ORDER BY s.category COLLATE NOCASE
    """)
    fun observeCategories(type: ContentType): Flow<List<CategoryCount>>

    @Query("""
        SELECT s.contentKey AS contentKey, s.type AS type, MIN(s.title) AS title,
               s.category AS category, MAX(s.logo) AS logo, COUNT(*) AS sourceCount
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND s.type = :type AND (:category IS NULL OR s.category = :category)
        GROUP BY s.contentKey
        ORDER BY MIN(s.title) COLLATE NOCASE
    """)
    fun pageItems(type: ContentType, category: String?): PagingSource<Int, UnifiedItem>

    @Query("""
        SELECT s.contentKey AS contentKey, s.type AS type, MIN(s.title) AS title,
               s.category AS category, MAX(s.logo) AS logo, COUNT(*) AS sourceCount
        FROM streams s
        JOIN streams_fts ON streams_fts.rowid = s.id
        JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND streams_fts MATCH :query
          AND (:type IS NULL OR s.type = :type)
        GROUP BY s.contentKey
        ORDER BY s.type, MIN(s.title) COLLATE NOCASE
    """)
    fun search(query: String, type: ContentType?): PagingSource<Int, UnifiedItem>

    @Query("""
        SELECT s.contentKey AS contentKey, s.type AS type, MIN(s.title) AS title,
               s.category AS category, MAX(s.logo) AS logo, COUNT(*) AS sourceCount
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        JOIN favorites f ON f.contentKey = s.contentKey
        WHERE p.enabled = 1 AND s.type = :type
        GROUP BY s.contentKey ORDER BY MIN(s.title) COLLATE NOCASE
    """)
    fun pageFavorites(type: ContentType): PagingSource<Int, UnifiedItem>

    /** Encontra o canal IPTV que corresponde à emissora informada pelo placar. */
    @Query("""
        SELECT s.contentKey AS contentKey, s.type AS type, MIN(s.title) AS title,
               s.category AS category, MAX(s.logo) AS logo, COUNT(*) AS sourceCount
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND s.type = 'LIVE'
          AND lower(s.title) LIKE '%' || lower(:network) || '%'
        GROUP BY s.contentKey ORDER BY MIN(p.priority), MIN(s.title) COLLATE NOCASE LIMIT 1
    """)
    suspend fun findLiveChannel(network: String): UnifiedItem?

    @Query("""
        SELECT s.url AS url, s.userAgent AS userAgent, s.referer AS referer,
               p.name || CASE WHEN s.variant IS NULL THEN '' ELSE ' • ' || s.variant END AS sourceName
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND s.contentKey = :key AND s.url <> ''
        ORDER BY p.priority, s.id
    """)
    suspend fun sourcesFor(key: String): List<StreamSource>

    @Query("""
        SELECT s.contentKey AS contentKey, s.type AS type, MIN(s.title) AS title,
               s.category AS category, MAX(s.logo) AS logo, COUNT(*) AS sourceCount
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND s.contentKey = :key GROUP BY s.contentKey
    """)
    suspend fun item(key: String): UnifiedItem?

    @Query("""
        SELECT s.playlistId AS playlistId, s.seriesRef AS seriesRef, p.generation AS generation
        FROM streams s JOIN playlists p ON p.id = s.playlistId
        WHERE p.enabled = 1 AND p.type = 'XTREAM' AND s.contentKey = :key AND s.seriesRef IS NOT NULL
    """)
    suspend fun xtreamSeriesRefs(key: String): List<XtreamSeriesRef>

    @Query("SELECT COUNT(*) FROM episodes WHERE playlistId = :pid AND seriesKey = :key")
    suspend fun countEpisodes(pid: Long, key: String): Int

    @Query("""
        SELECT e.season AS season, e.episode AS episode, e.title AS title, e.url AS url,
               e.logo AS logo, e.userAgent AS userAgent, e.referer AS referer,
               p.name || CASE WHEN e.variant IS NULL THEN '' ELSE ' • ' || e.variant END AS sourceName
        FROM episodes e JOIN playlists p ON p.id = e.playlistId
        WHERE p.enabled = 1 AND e.seriesKey = :key
        ORDER BY e.season, e.episode, p.priority
    """)
    suspend fun episodesFor(key: String): List<EpisodeSource>

    // ---------- favoritos ----------
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE contentKey = :key)")
    fun observeIsFavorite(key: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE contentKey = :key") suspend fun removeFavorite(key: String)
}
