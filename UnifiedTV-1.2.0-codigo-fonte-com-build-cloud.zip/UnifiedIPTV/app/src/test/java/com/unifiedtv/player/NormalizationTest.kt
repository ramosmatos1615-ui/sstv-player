package com.unifiedtv.player

import com.unifiedtv.player.data.db.ContentType
import com.unifiedtv.player.data.db.ContentType.*
import com.unifiedtv.player.data.normalize.*
import com.unifiedtv.player.data.parser.M3uEntry
import com.unifiedtv.player.data.parser.M3uParser
import org.junit.Assert.*
import org.junit.Test

class NormalizationTest {
    private fun entry(title: String, url: String, group: String? = null, duration: Double? = -1.0, attrs: Map<String, String> = emptyMap()) =
        M3uEntry(title, url, attrs, group, null, null, duration)

    private fun type(title: String, url: String, group: String? = null, duration: Double? = -1.0) =
        ContentClassifier.classify(entry(title, url, group, duration)).type

    @Test fun mergesSameChannelAcrossLists() {
        val a = TextNormalizer.contentKey(LIVE, "BR | ESPN HD")
        assertEquals("L:espn", a)
        assertEquals(a, TextNormalizer.contentKey(LIVE, "[BR] ESPN FHD"))
        assertEquals(a, TextNormalizer.contentKey(LIVE, "ESPN (Backup)"))
        assertNotEquals(a, TextNormalizer.contentKey(LIVE, "ESPN 2 HD"))
    }

    @Test fun liveChannels() {
        assertEquals(LIVE, type("Globo SP HD", "http://srv:8080/user/pass/1234", "CANAIS | ABERTOS"))
        assertEquals(LIVE, type("Telecine Action", "http://srv:8080/user/pass/55.ts", "CANAIS | FILMES E SÉRIES"))
        assertEquals(LIVE, type("ESPN", "http://cdn.x.com/espn/index.m3u8", "Esportes"))
        // canal 24h com nome de série continua ao vivo
        assertEquals(LIVE, type("24H Chaves", "http://srv/u/p/900.ts", "SÉRIES 24H"))
        assertEquals(LIVE, type("Os Simpsons 24/7", "http://cdn/simpsons.m3u8", "Desenhos"))
        assertEquals(LIVE, type("Rádio Jovem Pan", "http://radio/stream", "Rádios"))
    }

    @Test fun ambiguousGroups() {
        assertEquals(LIVE, type("Discovery Kids", "http://srv:80/u/p/77", "Infantil"))
        assertEquals(MOVIE, type("Frozen (2013)", "http://cdn/frozen.mp4", "Infantil"))
        assertEquals(SERIES, type("Bluey S02E10", "http://cdn/bluey/210.mp4", "Infantil"))
        assertEquals(LIVE, type("HBO Family FHD", "http://srv/u/p/12.ts", "CANAIS HBO"))
        assertEquals(LIVE, type("SporTV 2", "http://cdn/sportv2/playlist.m3u8", "Esportes"))
    }

    @Test fun movies() {
        assertEquals(MOVIE, type("Matrix (1999)", "http://srv/movie/u/p/10.mp4", "FILMES | AÇÃO"))
        assertEquals(MOVIE, type("Duna Parte 2 [2024] 4K Dublado", "http://cdn/duna2.mkv", "Lançamentos"))
        assertEquals(MOVIE, type("Oppenheimer", "http://cdn/vod/opp.m3u8", "VOD"))
        assertEquals(MOVIE, type("Interestelar", "http://cdn/files/inter.mp4", "Ficção", 10140.0))
        // título com "Ep" no nome não vira série
        assertEquals(MOVIE, type("Star Wars Episódio IV (1977)", "http://cdn/sw4.mp4", "Filmes | Sagas"))
        assertEquals(MOVIE, type("Velozes e Furiosos 5 (2011)", "http://cdn/vf5.mp4", "Filmes"))
    }

    @Test fun moviesTitleAndYear() {
        assertEquals(MediaTitleParser.MovieInfo("Blade Runner 2049", 2017), MediaTitleParser.parseMovie("Blade Runner 2049 (2017) [4K]"))
        assertEquals(MediaTitleParser.MovieInfo("1917", null), MediaTitleParser.parseMovie("1917"))
        assertEquals(MediaTitleParser.MovieInfo("Matrix", 1999), MediaTitleParser.parseMovie("BR | Matrix - 1999 Dublado"))
        assertEquals(TextNormalizer.vodKeys(MOVIE, "Matrix", 1999).first,
            TextNormalizer.vodKeys(MOVIE, MediaTitleParser.parseMovie("Matrix (1999) [LEG] FHD").name, 1999).first)
    }

    @Test fun seriesPatterns() {
        fun ep(t: String, g: String? = null) = MediaTitleParser.parseEpisode(t, g)!!
        ep("Dark S01E02").let { assertEquals("Dark", it.showName); assertEquals(1, it.season); assertEquals(2, it.episode) }
        ep("Dark.S02E05.1080p.WEB-DL").let { assertEquals("Dark", it.showName); assertEquals(2, it.season); assertEquals(5, it.episode) }
        ep("The Office 3x07").let { assertEquals("The Office", it.showName); assertEquals(3, it.season); assertEquals(7, it.episode) }
        ep("La Casa de Papel T02 EP04").let { assertEquals("La Casa de Papel", it.showName); assertEquals(2, it.season); assertEquals(4, it.episode) }
        ep("Breaking Bad - Temporada 4 Episódio 13").let { assertEquals("Breaking Bad", it.showName); assertEquals(4, it.season); assertEquals(13, it.episode) }
        ep("Round 6 2ª Temporada Ep 3").let { assertEquals("Round 6", it.showName); assertEquals(2, it.season); assertEquals(3, it.episode) }
        ep("Dark (2017) S01E01 - Segredos [DUB]").let {
            assertEquals("Dark", it.showName); assertEquals(2017, it.year); assertEquals("Segredos", it.episodeTitle)
        }
        ep("Avenida Brasil Capítulo 120").let { assertEquals("Avenida Brasil", it.showName); assertEquals(120, it.episode); assertFalse(it.strong) }
        ep("Episódio 05", "Séries | Breaking Bad - Temporada 2").let { assertEquals("", it.showName); assertEquals(2, it.season); assertEquals(5, it.episode) }
    }

    @Test fun seriesClassification() {
        val a = ContentClassifier.classify(entry("Dark S01E01", "http://srv/series/u/p/1.mkv", "SÉRIES | NETFLIX"))
        assertEquals(SERIES, a.type); assertEquals("Dark", a.episode!!.showName)
        // nome da série vem do grupo quando o título só tem o número do episódio
        val b = ContentClassifier.classify(entry("Episódio 05", "http://cdn/bb/205.mp4", "Séries | Breaking Bad - Temporada 2"))
        assertEquals(SERIES, b.type); assertEquals("Breaking Bad", b.episode!!.showName); assertEquals(2, b.episode!!.season)
        val c = ContentClassifier.classify(entry("Breaking Bad 07", "http://cdn/bb/207.mp4", "Breaking Bad Temporada 2"))
        assertEquals(SERIES, c.type); assertEquals(7, c.episode!!.episode)
        assertEquals(SERIES, type("Avenida Brasil Capítulo 120", "http://cdn/av/120.mp4", "Novelas"))
        // VOD em grupo de série sem número de episódio vira filme
        assertEquals(MOVIE, type("Especial de Natal (2020)", "http://cdn/x.mp4", "Séries"))
    }

    @Test fun groupProfileResolvesAmbiguity() {
        // grupo "NETFLIX" com HLS: sem perfil seria ao vivo; o perfil do grupo indica filmes
        val group = "NETFLIX"
        val entries = listOf(
            entry("Bird Box (2018)", "http://cdn/a.mp4", group),
            entry("O Irlandês (2019)", "http://cdn/b.mp4", group),
            entry("Roma (2018)", "http://cdn/c.mkv", group),
            entry("Alerta Vermelho", "http://cdn/vod/d/index.m3u8", group)
        )
        val prof = GroupProfiler().apply { entries.forEach { add(it) } }
        assertEquals(MOVIE, ContentClassifier.classify(entries[3], prof.prior(group)).type)
    }

    @Test fun variants() {
        assertEquals("DUB • 4K", MediaTitleParser.detectVariant("Duna [2024] 4K Dublado"))
        assertEquals("LEG", MediaTitleParser.detectVariant("Dark S01E01 [L]"))
        assertEquals("DUAL • FHD", MediaTitleParser.detectVariant("Matrix Dual Audio 1080p"))
    }

    @Test fun categories() {
        assertEquals("Esportes", CategoryNormalizer.normalize(LIVE, "BR | ESPORTES HD"))
        assertEquals("Terror", CategoryNormalizer.normalize(MOVIE, "FILMES | HORROR"))
        assertEquals("Netflix", CategoryNormalizer.normalize(SERIES, "Séries Netflix"))
        assertEquals("Coleções", CategoryNormalizer.normalize(MOVIE, "Coletânea Harry Potter"))
        assertEquals("Outros Filmes", CategoryNormalizer.normalize(MOVIE, "FILMES"))
        assertEquals("Outras Séries", CategoryNormalizer.normalize(SERIES, "Breaking Bad - Temporada 2", "breaking bad"))
    }

    @Test fun parsesM3uWithDuration() {
        val m3u = """
            #EXTM3U
            #EXTINF:-1 tvg-id="espn.br" tvg-logo="http://x/l.png" group-title="Esportes, Ao Vivo",ESPN HD
            #EXTVLCOPT:http-user-agent=MyUA
            http://host/live/u/p/1.ts
            #EXTINF:7260 tvg-name="Matrix (1999)" group-title="Filmes",Matrix
            http://host/files/matrix.mp4
        """.trimIndent()
        val list = M3uParser.entries(m3u.reader().buffered()).toList()
        assertEquals(2, list.size)
        assertEquals("Esportes, Ao Vivo", list[0].group); assertEquals("MyUA", list[0].userAgent)
        assertEquals(-1.0, list[0].duration!!, 0.0); assertEquals(7260.0, list[1].duration!!, 0.0)
        val r = ContentClassifier.classify(list[1])
        assertEquals(MOVIE, r.type); assertEquals(1999, r.movie!!.year)   // ano vindo do tvg-name
    }

    @Test fun ftsQuery() = assertEquals("acao* rapida*", TextNormalizer.ftsQuery("Ação  rápida"))
}
